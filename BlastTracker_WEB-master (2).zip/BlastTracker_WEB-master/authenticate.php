<?php
//Start session
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$pwd = '';
$ch = require "include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url . "login/" . $username);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
$key = "SECRETKEY";
if(isset($data['password'])){
$pwd = openssl_decrypt(($data['password']), "AES-128-ECB",$key);
}
if($pwd == $password){
    session_regenerate_id();
    $_SESSION['SESS_MEMBER_ID'] = $data['userId'];
    $_SESSION['SESS_FIRST_NAME'] = $data['userName'];
    $_SESSION['SESS_ROLE_ID'] = $data['roleId'];
    $_SESSION['SESS_SUBCON_ID'] = $data['subConId'];
    $_SESSION['SESSS_TITLE'] = "Blaster Tracker";
    //$_SESSION['SESS_Company_ID'] = $member['Company_ID'];
    //$_SESSION['SESS_PRO_PIC'] = $member['profImage'];
    session_write_close();
    if($data['subConId'] == 5){
        header("location: main/inventory.php?subConId=all");
   }
   else{
    header("location: main/inventory.php?subConId=".$data['subConId']);

   }
    
    exit();
}else{
    echo "<script type='text/javascript'> 
    alert ('Incorrect username or password');
    window.open('index.php"."','_self');

</script>";
   
}


?> 
