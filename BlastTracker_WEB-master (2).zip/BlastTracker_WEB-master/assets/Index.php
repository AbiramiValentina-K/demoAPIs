<?php
echo "<script type='text/javascript'> 
    alert ('Not able to access this page');
    window.open('../index.php"."','_self');

</script>";
?>   