<?php
	//Start session
	session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	unset($_SESSION['SESS_FIRST_NAME']);
	unset($_SESSION['SESS_LAST_NAME']);
?>
<html>
    <head>
        <title>Blaster Tracking</title>
        <meta charset="uts-8">
        
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" type="image/png" href=".\assets\icon.png">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
 
  <body>
        <div class="slider">
            <div class="slides">
                <input type="radio" name="radio-btn" id="radio1" class="radio">
                <input type="radio" name="radio-btn" id="radio2">
                <!-- <input type="radio" name="radio-btn" id="radio3">
                <input type="radio" name="radio-btn" id="radio4"> -->
               <div class="slide first">
                   <img src=".\assets\images\banner01.PNG" alt="">
                </div>
                <div class="slide">
                    <img src=".\assets\images\banner02.PNG" alt="">
                 </div>
                 <!-- <div class="slide">
                    <img src=".\assets\images\img3.PNG" alt="">
                 </div>
                 <div class="slide">
                    <img src=".\assets\images\img4.PNG" alt="">
                 </div> -->
                 <!--slide images end-->
                 <!--automatic navigation start-->
                 <div class="navigation-auto">
                     <div class="auto-btn1"></div>
                     <div class="auto-btn2"></div>
                     <!-- <div class="auto-btn3"></div>
                     <div class="auto-btn4"></div> -->
                 </div>
                 <!--automatic navigation end-->
            </div>
            <!--manual navigation start-->
            <div class="navigation-manual">
                <label for="radio1" class="manual-btn"></label>
                <label for="radio2" class="manual-btn"></label>
                <!-- <label for="radio3" class="manual-btn"></label>
                <label for="radio4" class="manual-btn"></label> -->
            </div>
            <!--manual navigation end-->
               
        </div>
          <div class="login-menu">
             <form action="authenticate.php" method="POST" class="form">
            <div class="login-page">
                <ul>
                    <li><i class="fa fa-user" ></i> <input type="text" placeholder="User-Id" name="username" required></li>
                    <li><i class="fa fa-thin fa-key"></i> <input type="password" placeholder="password" name="password" id="password"  required></li>
                    <span onclick="myfunction()"id="eye"><i class=" fa fa-solid fa-eye" id="eye_show"></i>
                    <i class=" fa fa-solid fa-eye-slash" id="eye_hide"></i></span>
                </ul>
                <input type="checkbox" class="check-box"><span >Remember Me</span>
                <button type="submit" class="submit-btn"  style="cursor:pointer;">Login</button></a><br>
                <p><a href="#" >Forgot Password?</a></p>

            </div>
        
            </form>
        </div>
        <script type="text/javascript">
            var i= 1;
            setInterval(function(){
                document.getElementById('radio'+i).checked = true;
                i++;
                if(i>4){
                    i=1;
                }
            },3000);
            function myfunction(){
            var x = document.getElementById("password");
            var y = document.getElementById("eye_show");
            var z = document.getElementById("eye_hide");
            if (x.type ==='password'){
                x.type="text";
                y.style.display="block";
                z.style.display="none";
            }
            else{
                x.type="password";
                y.style.display="none";
                z.style.display="block";
            }
        }
        </script>

    </body>
</html>