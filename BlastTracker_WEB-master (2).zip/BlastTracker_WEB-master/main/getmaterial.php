<?php
require_once('../include/auth.php');

$length = $_GET['length'];
$breadth = $_GET['breadth'];
$height = $_GET['height'];
$radius = $_GET['radius'];


$ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."material/fetch/".$length."/".$breadth."/".$height."/".$radius);
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);

$result = array("$length", "$breadth","$height","$radius");

// Send in JSON encoded form
$myJSON = json_encode($data);
echo $myJSON;
?>