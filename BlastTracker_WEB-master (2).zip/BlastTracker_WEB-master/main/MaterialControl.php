<?php
require_once('../include/init_curl.php');
require_once('../include/auth.php');
require_once('../include/common.php');
$menuId = 4;
validateUserRights($menuId,$_SESSION['SESS_ROLE_ID']);  

    if ($_GET['action'] == 'new') {
  $id=0;
  $materialDescription  = $uom= '';
  $consumeType = 'C';
}
if ($_GET['action'] == 'edit') {

              $ch = require "../include/init_curl.php";
              $id = $_GET['id'];
              curl_setopt($ch, CURLOPT_URL, $url."material/".$id);
                
                $response = curl_exec($ch);
                curl_close($ch);
                $item = json_decode($response, true);
 
  $materialDescription = $item['materialDescription'];
  $uom = $item['uomId'];
  $consumeType = $item['consumeType'];


}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add/Edit Material | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" href="..//facebox/src/facebox.css">
  <!-- <link rel="stylesheet" href="css/font-awesome/font-awesome.min.css"> -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
<script>
  $.facebox.settings.closeImage = '../facebox/closelabel.png';
$.facebox.settings.loadingImage = '../facebox/loading.gif';
   jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
</script>
</head>

<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">
    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="material.php">Material</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $_GET['action'] == 'edit' ? 'Edit' : 'New'; ?></li>
          </ol>
        </nav>
      </div>
    </div>

  
    <form action="SaveMaterial.php" method="POST">

      <input type="hidden" name="materialId" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="<?php echo $_GET['action']; ?>">

      <div class="row no-gutters">
        <div class="col-md-6 p-1">
        <div class="floating-label">      
        <input type="text" class="floating-input"  name="materialDescription"  value="<?php echo $materialDescription; ?>" placeholder=" " required>
        <label>Material Description</label>
        </div>

        </div>

        <div class="col-md-4 p-1">
        <div class="floating-label">
          
          <select class="floating-select"  name="uomId" required>
          <option value="" selected></option>

          <?php
          $ch = require "../include/init_curl.php";

          curl_setopt($ch, CURLOPT_URL, $url."uom/all");
          $response = curl_exec($ch);
          curl_close($ch);
          $data = json_decode($response, true);
          foreach($data as $row) {

          ?>

          <option value="<?php echo $row['uomId'] ?>" <?php echo ($uom== $row['uomId']) ? 'selected' : ''; ?>><?php echo $row['fullName'] ?></option>

          <?php
          }
          ?>
          </select>

        <label>uom</label>
        </div>
        </div>
        <div class="col-md-2 p-1">
        <a href="uom.php?action=new" rel="facebox" role="button" style="width:100px" class="form-control btn btn-primary"><b>+ </b>uom </a>
        </div>
      </div> 
      <div class="col-md-4 p-1">
        <div class="floating-label">  
        <select name="consumeType" class="floating-select" placeholder = "" required >
          <option value=""></option>
          <option value="C" <?php echo ($consumeType == 'C') ? 'selected': ''; ?>>Consumable </option>
          <option value="NC" <?php echo ($consumeType == 'NC') ? 'selected': ''; ?>>Non Consumable </option>
        </select>
        <label>Consume Type</label> 
        </div>
        </div>


      <div class="row no-gutters d-flex justify-content-center form-group mt-3">
        <button type="submit" class="form-control btn btn-block btn-primary" style="max-width: 350px"><i class="fa fa-save"></i> Save</button>
      </div>
    </form>
  </div>

  <?php include_once('../include/footer.php'); ?>
  <script src="../js/script.js"></script>
</body>

</html>