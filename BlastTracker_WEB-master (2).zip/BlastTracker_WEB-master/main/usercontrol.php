<?php
require_once('../include/init_curl.php');
require_once('../include/auth.php');


if ($_GET['action'] == 'new') {
  $id = 0;
  $loginId = $username = $pwd  = $role = $projectid = $psid = $phonenumber = $emailid = $subConId1 = '';
  $date = date("Y-m-d");
  $canEditControl = '';
}
if ($_GET['action'] == 'edit') {

  $ch = require "../include/init_curl.php";
  $id = $_GET['id'];
  curl_setopt($ch, CURLOPT_URL, $url . "user/" . $id);
  $response = curl_exec($ch);
  curl_close($ch);
  $item = json_decode($response, true);
  $loginId = $item['loginId'];
  $username = $item['userName'];
  $role = $item['roleId'];
  $key = "SECRETKEY";
  $pwd = openssl_decrypt($item['password'], "AES-128-ECB", $key);
  // $pwd = $item['password'];
  $subConId1 = $item['subConId'];
  $phonenumber = $item['phoneNumber'];
  $emailid = $item['emailId'];
  $date = date("Y-m-d");
  $canEditControl = 'readonly';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add/Edit User | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>

  <link rel="stylesheet" href="..//facebox/src/facebox.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <!-- <link rel="stylesheet" href="css/font-awesome/font-awesome.min.css"> -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">

  <script>
    $.facebox.settings.closeImage = '../facebox/closelabel.png';
    $.facebox.settings.loadingImage = '../facebox/loading.gif';
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
  </script>
</head>

<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">
    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item"><a href="user.php?subConId=all">User</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $_GET['action'] == 'edit' ? 'Edit' : 'New'; ?></li>
          </ol>
        </nav>
      </div>
    </div>


    <form action="saveuser.php" method="POST">

      <input type="hidden" name="userId" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="<?php echo $_GET['action']; ?>">
      <input type="hidden" name="modifiedBy" value="<?php echo $_SESSION['SESS_MEMBER_ID']; ?>">

      <?php if ($_GET['action'] == 'new') { ?>
        <input type="hidden" name="createdDate" value="<?php echo $date; ?>">
      <?php } else { ?>
        <input type="hidden" name="modifiedDate" value="<?php echo $date; ?>">

      <?php } ?>

      <div class="row no-gutters">
        <div class="col-md-6 p-1">
          <div class="floating-label">
            <select class="floating-select" name="subConId" required>
              <option value="" selected></option>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "subContractor/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['subConId'] ?>" <?php echo ($row['subConId'] == $subConId1) ? 'selected' : ''; ?>><?php echo $row['subConName'] ?></option>

              <?php
              }
              ?>

            </select>

            <label>Sub Contractor</label>
          </div>
        </div>


        <div class="col-md-6 p-1">
          <div class="floating-label">
            <input type="text" class="floating-input" name="userName" maxlength="50" onkeypress="return blockSpecialChar(event)" value="<?php echo $username; ?>" placeholder=" " required>
            <label>User Name</label>
          </div>

        </div>

      </div>


      <div class="row no-gutters">
        <div class="col-md-6 p-1">
          <div class="floating-label">
            <input type="text" class="floating-input" id="loginId" onkeypress="return blockSpecialChar(event)" onchange="existsLoginId()" name="loginId" maxlength="50" value="<?php echo $loginId; ?>" placeholder=" " required>
            <label>Login Id</label>

          </div>

        </div>

        <div class="col-md-6 p-1">
          <div class="floating-label">
            <input type="password" class="floating-input" name="password" minlength="8" maxlength="25" value="<?php echo $pwd; ?>" placeholder=" " required>
            <label>Password</label>
          </div>
        </div>

      </div>



      <div class="row no-gutters">
        <div class="col-md-6 p-1">
          <div class="floating-label">

            <select class="floating-select" name="roleId" required>
              <option value="" selected></option>

              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "userrole/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['roleId'] ?>" <?php echo ($role == $row['roleId']) ? 'selected' : ''; ?>><?php echo $row['roleName'] ?></option>

              <?php
              }
              ?>
            </select>

            <label>Role</label>

          </div>

        </div>

        <div class="col-md-6 p-1">

          <div class="floating-label">
            <input type="email" class="floating-input" name="emailId" value="<?php echo $emailid; ?>" placeholder=" " required>
            <label>Email ID</label>
          </div>
        </div>
      </div>

      <div class="row no-gutters">
        <div class="col-md-6 p-1">
          <div class="floating-label">
            <input type="text" class="floating-input" onkeypress="return onlyNumber(event)" name="phoneNumber" minlength="10" maxlength="10" value="<?php echo $phonenumber; ?>" placeholder=" " required>
            <label>Phone Number</label>
          </div>

        </div>

      </div>

      <div class="row no-gutters d-flex justify-content-center form-group mt-3">
        <button type="submit" class="form-control btn btn-block btn-primary" style="max-width: 200px"><i class="fa fa-save"></i> Save</button>
      </div>
    </form>
  </div>
  <script type="text/javascript">
    function blockSpecialChar(e) {
      var k;
      document.all ? k = e.keyCode : k = e.which;
      return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
    }

    function onlyNumber(e) {
      var k;
      document.all ? k = e.keyCode : k = e.which;
      return (k == 8 || k == 32 || (k >= 48 && k <= 57));
    }

    function existsLoginId(){
    var loginId = document.getElementById("loginId");
    var loginId  = loginId.value;


    var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {


        if (this.readyState == 4 &&
          this.status == 200) {


          var myObj = JSON.parse(this.responseText);
          
          var existsLoginId = myObj.loginId;
          if(existsLoginId == loginId)
          {
            alert("LoginId " + loginId + " Already Exists");
            document.getElementById("loginId").value = ''; 
          }

        }
      };

      xmlhttp.open("GET", "getLoginId.php?id=" + loginId, true);

      xmlhttp.send();
  }
  </script>
  <?php include_once('../include/footer.php'); ?>
  <script src="../js/script.js"></script>
</body>

</html>