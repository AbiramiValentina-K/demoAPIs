<?php
require_once('../include/auth.php');
$ch = require "../include/init_curl.php";

$id = $_POST['projectMappingId'];
$action = $_POST['action'];
var_dump(json_encode($_POST));
$ch = require "../include/init_curl.php";
if ($action == 'new') {

    curl_setopt($ch, CURLOPT_URL, $url . "projectMapping/add/");
} elseif ($action == 'edit') {
    curl_setopt($ch, CURLOPT_URL, $url . "/projectMapping/" . $id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
}
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($_POST));


$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
header("location: ProjectMapping.php");
if ($status_code === 422) {

    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {

    echo "Unexpected status code: $status_code";
    var_dump($data);
    exit;
}
?>