<?php
require_once('../include/auth.php');
$ch = require "../include/init_curl.php";

$id = $_POST['userId'];
$action = $_POST['action'];
$key = 'SECRETKEY';
$password = openssl_encrypt($_POST['password'], "AES-128-ECB", $key);;
$ch = require "../include/init_curl.php";
$_POST["password"] =  $password;
if ($action == 'new') {

    curl_setopt($ch, CURLOPT_URL, $url . "user/add/");
} elseif ($action == 'edit') {
    curl_setopt($ch, CURLOPT_URL, $url . "/user/" . $_POST['userId']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
}
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($_POST));


$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
header("location: user.php?subConId=all");
if ($status_code === 422) {

    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {

    echo "Unexpected status code: $status_code";
    var_dump($data);
    exit;
}
?>