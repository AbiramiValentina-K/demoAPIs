<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
          <ol class="breadcrumb" style="width: 500px">
            <li class="breadcrumb-item"  ><a href="#">Sub Contractor</a></li>
          </ol>
    <form action="SaveSubCon.php" method="POST">
      <input type="hidden" name="subConId" value="0">

      <div class="row no-gutters">
        <div class="col-md-6 p-1">
        <div class="floating-label">      
        <input type="text" class="floating-input" style="width: 350px" name="subConName" placeholder=" " required>
        <label>Sub Contractor Name</label>
        </div>
      </div>



      <div class="row no-gutters d-flex justify-content-center form-group mt-3">
        <button type="submit" class="form-control btn btn-block btn-primary" style="width: 350px"><i class="fa fa-save"></i> Save</button>
      </div>
    </form>


  <script src="../js/script.js"></script>

</body>
</html>