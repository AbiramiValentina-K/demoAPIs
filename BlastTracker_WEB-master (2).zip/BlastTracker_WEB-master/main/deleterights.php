<?php
require_once('../include/auth.php');
$ch = require "../include/init_curl.php";
$roleId = 3;
curl_setopt($ch, CURLOPT_URL, $url."menurights/".$roleId);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

$response = curl_exec($ch);

$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
// header("location: Rights.php?action=new");

if ($status_code === 422) {
    
    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}
if ($status_code === 200) {
    
    echo "Delete Success Fully: $status_code";
    var_dump($data);    
    exit;
}
if ($status_code !== 201) {
    
    echo "Unexpected status code: $status_code";
    var_dump($data);    
    exit;
}

?>


