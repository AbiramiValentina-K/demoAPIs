<?php
require_once('../include/auth.php');

$id = $_GET['id'];

if (ValidateStock($id) == "true") {
  $message = "User Exists in Blast or Stock Request Not Able to Delele";
  echo "<script type='text/javascript'> 
  alert ('" . $message . "');
  window.open('user.php?subConId=all"."','_self');
  </script>";
} elseif (ValidateStock($id) == "false") {

    $ch = require "../include/init_curl.php";

    curl_setopt($ch, CURLOPT_URL, $url."/user/".$id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

    $response = curl_exec($ch);

    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode($response, true);
    header("location: user.php?subConId=all");

    if ($status_code === 422) {
        
        echo "Invalid data: ";
        print_r($data["errors"]);
        exit;
    }

    if ($status_code !== 201) {
        
        echo "Unexpected status code: $status_code";
        var_dump($data);    
        exit;
    }
  }

function ValidateStock($id)
{
    $result = 'false';
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url . "blastingRequestHeader/findbyuserid/".$id);
    $sresponse = curl_exec($ch);
    curl_close($ch);
    $BlastList = json_decode($sresponse, true);

    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url . "stockTransferRequestHeader/findbyuserid/".$id);
    $sresponse = curl_exec($ch);
    curl_close($ch);
    $StockTransferList = json_decode($sresponse, true);


    if (count($BlastList) > 0 || count($StockTransferList) > 0) {
      $result = 'true';
  }


    return $result;
}


?>