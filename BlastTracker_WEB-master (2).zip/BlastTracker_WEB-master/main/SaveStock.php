<?php
require_once('../include/auth.php');

$id = $_POST['stockId'];
$subConId = $_POST['subConId'];
$ch = require "../include/init_curl.php";


curl_setopt($ch, CURLOPT_URL, $url."stock/".$id);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($_POST)); 
var_dump(json_encode($_POST));
echo $url."stock/".$id;
$response = curl_exec($ch);

$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
var_dump($data);
header("location:Inventory.php?subConId=".$subConId);

if ($status_code === 422) {
    
    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {
    
    echo "Unexpected status code: $status_code";
    var_dump($data);    
    exit;
}

?>
