<?php
require_once('../include/init_curl.php');
require_once('../include/auth.php');
require_once('../include/common.php');

$requiredmaterial = '';
$date = date("Y-m-d");
$roleId = $_SESSION['SESS_ROLE_ID'];

if ($_GET['action'] == 'new') {
  $id = 0;
  $materialId = $remarks = $FromSubConId = '';
  $subConId1 = $_SESSION['SESS_SUBCON_ID'];
  $userId = $_SESSION['SESS_MEMBER_ID'];
  $orderdate = date_create($date);
  $stockTransferRequestHeaderId = 0;
  $stockRequestId = $orderId  = 0;
  $status = "---";
  $caneditcontrol = "";
  $caneditbutton = "";
}

if (isset($_GET['status'])) {
  $status = $_GET['status'];
}

if ($roleId == 2) {
  $caneditcontrol = "";
  $caneditbutton = "";
  $caneditsubmit = "disabled";
}
if ($roleId == 3) {
  $caneditcontrol = "";
  $caneditbutton = "";
  $caneditsubmit = "disabled";
}
if ($status != '---') {
  $caneditcontrol = "readonly";
  $caneditbutton = "disabled";
  $caneditsubmit = "disabled";
} elseif ($status == 'Received' || $roleId == 1) {
  $caneditcontrol = "readonly";
  $caneditbutton = "disabled";
  $caneditsubmit = "disabled";
}


if ($_GET['action'] == 'edit') {

  $ch = require "../include/init_curl.php";
  $id = $_GET['id'];
  curl_setopt($ch, CURLOPT_URL, $url . "stockTransferRequestHeader/" . $id);
  $response = curl_exec($ch);
  curl_close($ch);
  $item = json_decode($response, true);
  $stockTransferRequestHeaderId = $_GET['id'];

  $subConId1 = $item['subConId'];
  $orderdate = date_create($item['date']);
  $orderId = $item['orderId'];
  $remarks = $item['remarks'];
  $userId = $item['userId'];
  $status = $_GET['status'];
  $stockRequestId = 0;
  $FromSubConId = '';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add/Edit Blaster Request |<?php echo $_SESSION['SESSS_TITLE']; ?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>

  <link rel="stylesheet" href="..//facebox/src/facebox.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <!-- <link rel="stylesheet" href="css/font-awesome/font-awesome.min.css"> -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
  <script>
    $.facebox.settings.closeImage = '../facebox/closelabel.png';
    $.facebox.settings.loadingImage = '../facebox/loading.gif';
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
  </script>
</head>

<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">
    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item new-gb"><a href="StockTransferList.php">Stock Transfer List</a></li>
            <li class="breadcrumb-item active text-white" aria-current="page"><?php echo $_GET['action'] == 'edit' ? 'Edit' : 'New'; ?></li>
          </ol>
        </nav>
      </div>
    </div>


    <form action="SaveStockRequest.php" method="POST">

      <input type="hidden" name="stockRequestId" value="<?php echo $stockRequestId; ?>">
      <input type="hidden" name="stockTransferRequestHeaderId" id="stockTransferRequestHeaderId" value="<?php echo $stockTransferRequestHeaderId; ?>">
      <input type="hidden" name="orderId" value="<?php echo $orderId; ?>">
      <input type="hidden" name="action" id="action" value="<?php echo $_GET['action']; ?>">
      <input type="hidden" name="userId" value="<?php echo $userId; ?>">
      <input type="hidden" name="roleId" value="<?php echo $roleId; ?>">
      <input type="hidden" name="subConId" value="<?php echo $subConId1; ?>">

      <?php if ($_GET['action'] == 'new') { ?>
        <input type="hidden" name="createdDate" value="<?php echo $date; ?>">
      <?php } else { ?>
        <input type="hidden" name="modifiedDate" value="<?php echo $date; ?>">

      <?php } ?>

      <div class="row no-gutters">
        <div class="col-md-4 p-1">
          <div class="floating-label">
            <input type="date" class="floating-input" min="<?php echo $date; ?>" <?php echo $caneditcontrol; ?> value="<?php echo date_format($orderdate, 'Y-m-d'); ?>" name="date" value placeholder=" " required>
            <label>Date</label>
          </div>
        </div>
        <div class="col-md-8 p-1">
          <div class="floating-label">
            <input type="text" class="floating-input" value="<?php echo $remarks; ?>" <?php echo $caneditcontrol; ?> name="remarks" value placeholder=" ">

            <label>Remarks</label>
          </div>
        </div>

      </div>



      <div class="row no-gutters" id="HeaderPart1">
        <input type="hidden" name="materialId1" value="" id="materialId1">

        <div class="col-md-4 p-1">
          <div class="floating-label">
            <select class="floating-select" id="material" onchange="loadQty()" <?php echo $caneditbutton; ?> name="stockList">
              <option value="" selected></option>
              <?php


              $ch = require "../include/init_curl.php";
              $url = $url . "stock/all/" . $subConId1;
              curl_setopt($ch, CURLOPT_URL, $url);
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $item) {

                if ($item['consumeType'] == 'C') {
                  $ch = require "../include/init_curl.php";

                  curl_setopt($ch, CURLOPT_URL, $url . "material/" . $item['materialId']);
                  $response = curl_exec($ch);
                  curl_close($ch);
                  $data = json_decode($response, true);

              ?>
                  <option value="<?php echo $item['stockId'] ?>"><?php echo $data['materialDescription']; ?></option>

              <?php
                }
              }
              ?>

            </select>

            <label>Material</label>
          </div>

        </div>

        <div class="col-md-3 p-1">
          <div class="floating-label">
            <input type="number" class="floating-input" <?php echo $caneditcontrol; ?> id="qty" name="qty" id="qty" value placeholder=" ">
            <label>Required Qty</label>
          </div>
        </div>
        <div class="col-md-3 p-1">
          <div class="floating-label">
            <button type="button" <?php echo $caneditbutton; ?> id="add" class="form-control btn btn-block btn-primary add-row" value="Add Row" style="max-width: 170px"><i class="fa fa-plus"></i> Add</button>
          </div>
        </div>

      </div>

      <div class="row no-gutters" id="HeaderPart2">

        <div class="col-md-3 p-1">
          <div class="floating-label">
            <select class="floating-select" <?php echo $caneditbutton; ?> name="fromSubConId" <?php if ($roleId == 3) {
                                                                                                echo "required";
                                                                                              } ?>>
              <option value="" selected></option>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "subContractor/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {
                if ($row['subConName'] != 'L&T User' && $row['subConId'] != $subConId1) {
              ?>

                  <option value="<?php echo $row['subConId'] ?>" <?php echo ($row['subConId'] == $FromSubConId) ? 'selected' : ''; ?>><?php echo $row['subConName'] ?></option>

              <?php
                }
              }
              ?>

            </select>

            <label>Sub Contractor</label>
          </div>
        </div>




      </div>


      <div>
        <table width="50%" id="materialTable" class="table">
          <thead>
            <tr>
              <th width="70%">Material Description</th>
              <th width="20%">Requested Qty</th>
              <?php if ($roleId == 3) {
                echo "<th width='10%'>Approved Qty</th>";
              } ?>
              <th width="20%">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>

            </tr>
          </tbody>
        </table>


      </div>
      <?php $btnclass = "";
      $btnInnerValue = "";
      if ($roleId == 3) {
        $btnclass = "form-control btn btn-block btn-warning";
        $btnInnerValue = "Save & Approve";
      } else {
        $btnclass = "form-control btn btn-block btn-primary";
        $btnInnerValue = "Save";
      } ?>

      <div class="row no-gutters d-flex justify-content-center form-group mt-3">
        <button type="submit" id="submit" <?php echo $caneditsubmit; ?> class="<?php echo $btnclass; ?>" style="max-width: 170px"><i class="fa fa-save"></i> <?php echo $btnInnerValue; ?></button>
      </div>
    </form>
  </div>
  </div>
  <script>
    var obj = [];
    var action = document.getElementById("action").value;

    $(document).ready(function() {

      var HeaderPart1 = document.getElementById("HeaderPart1");
      var HeaderPart2 = document.getElementById("HeaderPart2");


      function material_validate() {
        var result;
        var stockIdList = document.getElementsByName("stockId[]");
        var stockIdAdd = document.getElementById("material").value;
        if (stockIdList.length > 0) {
          for (var x = 0; x < stockIdList.length; x++) {

            var a = stockIdList[x];
            if (a.value == stockIdAdd) {
              alert("Material Already Added In List")
              $('#qty').val('');
              $('#material').val('');
              exit;

            }
          }
        }
      }
      var materialId1 = document.getElementById("materialId1");
      var material = document.getElementById("material");

      $(".add-row").click(function() {

        material_validate();
        var id = material.value;
        var materialId = materialId1.value;
        var materialDescription = material.options[material.selectedIndex].text;
        var qty = $("#qty").val();
        if (qty == '' || qty <= 0) {
          alert("Please Enter Valid Qty");
          document.getElementById("qty").value = '';
          exit;
        }

        if (id == '' || qty <= 0) {
          alert("Please Enter Valid Material");
          document.getElementById("material").value = '';
          exit;
        }

        var markup = "<tr><input type='hidden' class='floating-input' name='materialId[]' readonly value=" + materialId + "><input type='hidden' class='floating-input' name='stockId[]' readonly value=" + id + "><td><input type='text' class='floating-input' name='materialDescription[]' readonly value= " + "'" + materialDescription + "'" + "></td><td><input type='text' class='floating-input' readonly name='qty[]' value=" + qty + "></td><td><button type='button' class='form-control fa fa-trash btn btn-block btn-primary'  onclick='deleteRow()'></button></td></tr>";
        $("table tbody").append(markup);
        $('#qty').val('');
        $('#availableqty').val('');
        $('#material').val('');
        document.getElementById("submit").disabled = false;
      });

      // Find and remove selected table rows
      $('body').on('click', 'input.deleteDep', function() {
        $('td').click(function(e) {
          var txt = $(e.target).text();
          console.log(txt);
        })
      });

    });


    function validateQty() {
      var a = document.getElementById("availableqty");
      var b = document.getElementById("qty");
      var availableqty = parseInt(a.value);
      var qty = parseInt(b.value);



      if (availableqty < qty) {
        $('#qty').val('');

        alert(" Please Lesser Quantity ");
      }

    };

    if (action == "edit") {
      GetDetail(action);

    } else if (action == "new") {
      HeaderPart2.style.display = "none";
    }

    function GetDetail(str) {
      document.getElementById("submit").disabled = false;

      const stockTransferRequestHeaderId = document.getElementById('stockTransferRequestHeaderId').value;
      if (str.length == 0) {

        return;
      } else {

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {


          if (this.readyState == 4 &&
            this.status == 200) {


            var myObj = JSON.parse(this.responseText);
            var roleId = <?php echo $roleId; ?>;
            for (i = 0; i < myObj.length; i++) {
              console.log(myObj[i].stockTransferRequestDetailsId);

              var materialDesc = (myObj[i]["materialDescription"]);
              var markup = '';
              if (roleId == 3) {
                HeaderPart1.style.display = "none";
                markup = "<tr> <input type='hidden' class='floating-input' name='materialId[]' readonly value=" + myObj[i].materialId + "> <input type='hidden' <?php echo $caneditcontrol; ?> class='floating-input' name='stockId[]' readonly value=" +
                  myObj[i].stockId + "><td><input type='text' class='floating-input' readonly name='materialDescription[]'  value= " + '"' + materialDesc + '"' + "></td><td><input type='number' <?php echo $caneditcontrol; ?> class='floating-input' name='qty[]' readonly value=" + myObj[i].qty + "></td><td><input type='number' <?php echo $caneditcontrol; ?> class='floating-input' name='approvedQty[]' value=" + myObj[i].approvedQty + "></td><td><button type='button' <?php echo $caneditbutton; ?> class='form-control fa fa-trash btn btn-block btn-primary'  onclick='deleteRow(" + myObj[i].stockTransferRequestDetailsId + ")'></button></td></tr>";
              } else {
                HeaderPart2.style.display = "none";
                markup = "<tr><input type='hidden' class='floating-input' name='materialId[]' readonly value=" + myObj[i].materialId + "><input type='hidden' <?php echo $caneditcontrol; ?> class='floating-input' name='stockId[]' readonly value=" +
                  myObj[i].stockId + "><td><input type='text' class='floating-input' readonly name='materialDescription[]'  value= " + '"' + materialDesc + '"' + "></td><td><input type='number' <?php echo $caneditcontrol; ?> class='floating-input' name='qty[]' value=" + myObj[i].qty + "></td><td><button type='button' <?php echo $caneditbutton; ?> class='form-control fa fa-trash btn btn-block btn-primary'  onclick='deleteRow(" + myObj[i].stockTransferRequestDetailsId + ")'></button></td></tr>";
              }

              $("table tbody").append(markup);
            }
          }
        };

        xmlhttp.open("GET", "getStockTransferRequestDetails.php?id=" + stockTransferRequestHeaderId, true);

        xmlhttp.send();
      }
    }

    function deleteRow(stockTransferRequestDetailsId) {
      var td = event.target.parentNode;
      var tr = td.parentNode; // the row to be removed
      var xmlhttp = new XMLHttpRequest();

      xmlhttp.open("GET", "deleteStockTransferRequestDetails.php?id=" + stockTransferRequestDetailsId, true);
      xmlhttp.send();
      var x = document.getElementById("materialTable").rows.length;
      if (x == 3) {
        document.getElementById("submit").disabled = true;
      }
      tr.parentNode.removeChild(tr);
    }
  </script>

  <script>
    function enableAddBtn() {
      var material = document.getElementById("material").value;
      var qty = document.getElementById("qty").value;
      if (material > 0) {
        if (qty > 0) {
          document.getElementById("add").disabled = false;
        }
      } else if (qty == '') {
        document.getElementById("add").disabled = true;
      }
    }

    function loadQty() {
      var stock = document.getElementById("material");
      var stockId = stock.value;

      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {


        if (this.readyState == 4 &&
          this.status == 200) {


          var myObj = JSON.parse(this.responseText);
          document.getElementById("materialId1").value = myObj.materialId;


        }
      };

      xmlhttp.open("GET", "getStockQty.php?id=" + stockId, true);

      xmlhttp.send();
    }
  </script>
  <?php
  include_once('../include/footer.php'); ?>
  <script src="../js/script.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</body>

</html>