<?php
require_once('../include/auth.php');
require_once('../include/common.php');

$id = $_GET['id'];
$userId = $_SESSION['SESS_MEMBER_ID'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."blastingRequestHeader/".$id);
$response = curl_exec($ch);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);


    $RequestHeaderData["status"]="Approved";

    $orderId = $RequestHeaderData["orderId"];
    $RequestHeaderData["approvedById"] = $userId;

$ch = require "../include/init_curl.php";

    curl_setopt($ch, CURLOPT_URL, $url."/blastingRequestHeader/".$id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($RequestHeaderData)); 
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);

    
        $message = "Your Request Order Id  = ".$orderId . " Successfully Approved";
        echo "<script type='text/javascript'> 
            alert ('".$message."');
		    window.open('BlastRequestList.php"."','_self');
        
        </script>"
    

        

?>

<?php

   
    ?>