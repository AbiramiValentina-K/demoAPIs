<?php
$fromSubConId = $_GET['id'];

$ch = require "../include/init_curl.php";
$url = $url."stock/all/".$fromSubConId; 
curl_setopt($ch, CURLOPT_URL, $url);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
foreach($data as $item) {


  $ch = require "../include/init_curl.php";

  curl_setopt($ch, CURLOPT_URL, $url."material/".$item['materialId']);
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);
  
  ?>
