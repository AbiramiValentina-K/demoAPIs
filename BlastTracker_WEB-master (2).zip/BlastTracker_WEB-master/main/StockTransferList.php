<?php
require_once('../include/init_curl.php');
require_once('../include/auth.php');
require_once('../include/common.php');
$menuId1 = 11;
validateUserRights($menuId1,$_SESSION['SESS_ROLE_ID']);


$subConId = $_SESSION['SESS_SUBCON_ID'];

$roleId = $_SESSION['SESS_ROLE_ID'];
$fromDate = date_create(date("d-m-Y"));
$toDate = date_create(date("d-m-Y"));
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Stock Request List | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>


  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/all.css">

  <link rel="stylesheet" href="..//facebox/src/facebox.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
  <!-- <link rel="stylesheet" href="css/font-awesome/font-awesome.min.css"> -->
  <script>
    $.facebox.settings.closeImage = '../facebox/closelabel.png';
    $.facebox.settings.loadingImage = '../facebox/loading.gif';
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
  </script>
</head>
<style>
  #orderTable {
        font-family: Arial, Helvetica, sans-serif;
        width: 100%;
        text-align: center;
        border: 1px solid;
        padding: 10px;
        box-shadow: 10px -20px 35px #888888;

      }
     
      
      #orderTable td, #orderTable th {
        border: 1px solid #ddd;
        padding: 8px;
      }
      
      #orderTable tr:nth-child(even){background-color: #f2f2f2;}
      
      #orderTable tr:hover {background-color: #ddd;}
      
      #orderTable th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: center;
        background-color: #61A2FB;
        color: white;
      }
</style>
<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">
    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item active"><a href="StockTransferList.php">Stock Transfer Request List</a></li>
          </ol>
        </nav>
      </div>
    </div>
    <form method="POST">
    <div class="row no-gutters">
      <div class="col-md-4 p-1">
        <div class="floating-label">  
          <input type="date" class="floating-input" id="fromDate"  min="" value="<?php echo date_format($fromDate,'Y-m-d');?>"   name="fromDate"  value placeholder=" " required>
          <label>From Date</label> 
        </div>
      </div> 
      <div class="col-md-4 p-1">
        <div class="floating-label">  
          <input type="date" class="floating-input"  id="toDate" min="" value="<?php echo date_format($toDate,'Y-m-d');?>"   name="toDate"  value placeholder=" " required>
          <label>To Date</label> 
        </div>
      </div> 
      <div class="col-md-4 p-1">
         
          <input type="submit" class="form-control btn btn-block btn-primary add-row" value="Search">

      </div>
    </div> 
  </form>
  <div class="col-9 p-1">
          <input type="text" name="search" id="search" class="form-control" placeholder="Search in Order List">
        </div>
      <div class="row no-gutters p-1" id="myDiv">
        <div  class="table-responsive" id="userTable">
      <?php  if(isset($_POST['fromDate'])){
       $fromDate = date_create($_POST['fromDate']);
        $toDate = date_create($_POST['toDate']);}
       echo "<h4> From Date: ".date_format($fromDate,"d-m-Y")." To Date: ".date_format($toDate,"d-m-Y")."</h4>"; ?>

    <table id="orderTable" class="table">
      <th width=10%>Transfer ID</th>
      <th width=10%>Date</th>
      <th width=25%>Transfer From</th>
      <th width=25%>Transfer To</th>
      <th width=10%>Remarks</th>
      <th width=10%>Status</th>
      <th width=10%>More Info</th>
      <th width=10%>Received</th>
      <tbody>
        <?php
        // $ch = require "../include/init_curl.php";
        // if($roleId == 3){($url = $url."stockTransferRequestHeader/all");}
        // else { $url = $url . "stockTransferRequestHeader/subconid/".$subConId;}
        // $id = session_id();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // $response = curl_exec($ch);
        // curl_close($ch);
        // $data = json_decode($response, true);
        // foreach ($data as $row) {
          $ch = require "../include/init_curl.php";
                if ($roleId == 1 && $roleId == 2){
                  $subConId  = $subConId;
                }else{$subConId = 'all'; }
      
          curl_setopt($ch, CURLOPT_URL, $url . "stockTransferRequestHeader/findbydate/".date_format($fromDate,"Y-m-d")."/".date_format($toDate,"Y-m-d")."/".$subConId);
          $response = curl_exec($ch);
          curl_close($ch);
          $data = json_decode($response, true);
          foreach ($data as $row) {
        ?>
          <tr>
            <td><?php echo $row['orderId'] ?></td>
    
            <td>
            <?php
            $date = date_create($row['date']);
            echo date_format($date,'d-m-Y');
            ?>
            </td>
            <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."subContractor/".$row['fromSubConId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $subContractor = json_decode($response, true);
                if($subContractor==''){$fromSubConName = '---';}
                else{$fromSubConName = $subContractor['subConName']; }
                ?>
                <td><?php echo $fromSubConName; ?></td>
            <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."subContractor/".$row['subConId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $subContractor = json_decode($response, true);
                if($subContractor==''){$toSubconName = '---';}
                else{$toSubconName = $subContractor['subConName']; }
                ?>
                <td><?php echo $toSubconName; ?></td>
            <td><?php echo $row['remarks'];?></td>
            <td><?php echo $row['status'] ?></td>
            <td> <a href="StockRequest.php?action=edit&id=<?php echo $row['stockTransferRequestHeaderId']?>&status=<?php echo $row['status'] ?>"><i class="fa fa-angle-double-right"></i></a></td>
          <?php $btnclass = '';
          if($roleId==3 || $roleId==4 || $roleId==5){$btnclass = 'form-control btn btn-block btn-success disabled';}
          if($roleId == 1 || $roleId==2){$btnclass = 'form-control btn btn-block btn-success';}
          if($row['status'] == 'Received' || $row['status'] == 'Approved & Sipping'){$btnclass = 'form-control btn btn-block btn-success disabled';}
          ?>
            <td><a class="<?php echo $btnclass; ?>"  href="StockReceived.php?id=<?php echo $row['stockTransferRequestHeaderId']?>&subConId=<?php echo $row['subConId']; ?>">Received</a>  </td>
          <?php }?>

      </tbody>
      <div>
        <script src="../js/script.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>