<?php
require_once('../include/auth.php');

$id = $_GET['id'];


$ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."login/".$id);
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);


// Send in JSON encoded form
$myJSON = json_encode($data);
echo $myJSON;
?>