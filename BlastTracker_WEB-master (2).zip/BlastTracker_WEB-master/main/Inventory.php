<?php
require_once('../include/init_curl.php');
//Start session
session_start();
//fetch master data form material and uom
require_once('../include/common.php');
$menuId = 7;
validateUserRights($menuId, $_SESSION['SESS_ROLE_ID']);

$roleId = $_SESSION['SESS_ROLE_ID'];
$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url . "uom/all");
$response = curl_exec($ch);
curl_close($ch);
$uom = json_decode($response, true);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inventory | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>

  <link rel="stylesheet" href="..//facebox/src/facebox.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
  <script>
    $.facebox.settings.closeImage = '../facebox/closelabel.png';
    $.facebox.settings.loadingImage = '../facebox/loading.gif';
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
  </script>
</head>
<body>

  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>


  <div class="main container">

    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb new-bg">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item text-white" aria-current="page">Inventory</li>
          </ol>
        </nav>
      </div>
    </div>

    <script>
      function load_rights() {
        $var = document.getElementById("subConId").value;
        window.location = "Inventory.php?subConId=" + $var;
      }
    </script>


    <!--Sub Contractor Visible for Only Site Admin-->

    <div class="row no-gutters" id="FilterDiv">
      <div class="col-md-6 p-1">

        <select class="floating-select" name="subConId" id="subConId" onchange=load_rights() required>
          <option value="" selected></option>
          <option value="all" selected>ALL Sub Contractor</option>
          <?php

          $subConId = $_GET['subConId'];

          $ch = require "../include/init_curl.php";

          curl_setopt($ch, CURLOPT_URL, $url . "subContractor/all");
          $response = curl_exec($ch);
          curl_close($ch);
          $subContractor = json_decode($response, true);
          foreach ($subContractor as $row) {
            if ($row['subConId'] != 5) {
          ?>

              <option value="<?php echo $row['subConId'] ?>" <?php echo ($subConId == $row['subConId']) ? 'selected' : ''; ?>><?php echo $row['subConName'] ?></option>

          <?php
            }
          }
          ?>

        </select>

      </div>


      <div class="col-6 p-1">
        <input type="text" name="search" id="search" class="form-control" placeholder="Search in Material">
      </div>
      </div>



    <div class="row no-gutters p-1">
      <div class="table-responsive" id="userTable">
        <table class="table">
          <thead>
            <tr style="height:5px">
              <th width="20%">SubContractor</th>
              <th width="30%">Material Description</th>
              <th width="20%">Current Stock</th>
              <th width="10%">Unit</th>
              <?php if ($roleId == 1) { ?>
                <th width="20%">Add Inventory</th> <?php } ?>
                <?php if ($roleId == 3) { ?>
                <th width="20%">Approve Stock </th> <?php } ?>
            
              </tr>
            
          </thead>

          <tbody>
            <?php
            $ch = require "../include/init_curl.php";
            if ($subConId == 'all') {
              $url = $url . "stock/all";
            } else {
              $url = $url . "stock/all/" . $subConId;
            }
            curl_setopt($ch, CURLOPT_URL, $url);
            $response = curl_exec($ch);
            curl_close($ch);
            $data = json_decode($response, true);
            foreach ($data as $item) {

            ?>
              <tr class="record"  style="height:5px">

              <td>
                  <?php
                  $subConName = '';
                  foreach ($subContractor as $row) {
                    if ($row['subConId'] == $item['subConId']) {
                      echo $subConName = $row['subConName'];
                    }
                  }
                  ?></td>
                <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url . "material/" . $item['materialId']);
                $response = curl_exec($ch);
                
                curl_close($ch);
                $material = json_decode($response, true);
                ?>

                <td><?php echo $materialDescription = $material['materialDescription']; ?></td>
                <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url . "uom/" . $material['uomId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $data = json_decode($response, true);
                ?>
                <td><?php if ($material['consumeType'] == 'C') {
                      echo $item['qty'];
                    } elseif ($material['consumeType'] == 'NC') {
                      echo $item['nonConsumableQty'];
                    }

                    ?></td>
                <td><?php echo $data['singularName']; ?></td>
        
                <?php if ($roleId == 1 ) { ?>
                  <td class="actions">

                    <a rel="facebox" href="AddInventory.php?id=<?php echo $item['stockId'] . "&subConName=" . $subConName . "&uom=" . $data['singularName'] . "&materialDescription=" . $materialDescription . "&qty=" . $item['qty'] . "&subConId=" . $item['subConId'] . "&materialId=" . $item['materialId'] . "&consumeType=" . $material['consumeType']."&updatedQty=".$item['updatedQty'] ; ?>" title="Add Inventory">
                      <button class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></button>
                    </a>

                  </td>
                <?php } ?>

                  <?php if ($roleId == 3 ) { ?>
                  <td class="actions">

                    <a rel="facebox" href="AddInventory.php?id=<?php echo $item['stockId'] . "&subConName=" . $subConName . "&uom=" . $data['singularName'] . "&materialDescription=" . $materialDescription . "&qty=" . $item['qty'] . "&subConId=" . $item['subConId'] . "&materialId=" . $item['materialId'] . "&consumeType=" . $material['consumeType']."&updatedQty=".$item['updatedQty'] ; ?>" title="Add Inventory">
                      <button class="btn btn-success btn-sm"><i class="fa fa-check"></i></button>
                    </a>

                  </td>
      
                <?php } ?>
              </tr>

            <?php
            }
            ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php include_once('../include/Notification.php'); ?>
  <?php include_once('../include/footer.php'); ?>

  <script>
    window.onload = function HideSubContractor() {
      var element = document.getElementById("FilterDiv");
      var roleId = '<?php echo $roleId; ?>';
      if (roleId != 5 && roleId != 3) {
        element.style.display = "none";
      }
    }
  </script>
  <script>
    function filterTable(event) {
      var filter = event.target.value.toUpperCase();
      var rows = document.querySelector("#userTable tbody").rows;

      for (var i = 0; i < rows.length; i++) {
        var firstCol = rows[i].cells[0].textContent.toUpperCase();
        var secondCol = rows[i].cells[1].textContent.toUpperCase();
        if (firstCol.indexOf(filter) > -1 || secondCol.indexOf(filter) > -1)
          rows[i].style.display = "";
        else
          rows[i].style.display = "none";
      }
    }

    document.querySelector('#search').addEventListener('keyup', filterTable, false);
  </script>
  <script src="../js/script.js"></script>

</body>

</html>