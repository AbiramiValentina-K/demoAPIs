
<?php require_once('../include/auth.php');
  require_once('../include/common.php');
  $menuId = 2;
  validateUserRights($menuId,$_SESSION['SESS_ROLE_ID']);  
?>
  
          <ol class="breadcrumb" style="width: 500px">
            <li class="breadcrumb-item"  ><a href="#">Role</a></li>
          </ol>
      


    
  
    <form action="saverole.php" method="POST">
      <input type="hidden" name="role_id" value="0">

      <div class="row no-gutters">
        <div class="col-md-6 p-1">
        <div class="floating-label">      
        <input type="text" class="floating-input" style="width: 350px" name="roleName" placeholder=" " required>
        <label>Role</label>

        
        </div>

    
      </div>


      <div class="row no-gutters d-flex justify-content-center form-group mt-3">
        <button type="submit" class="form-control btn btn-block btn-info" style="width: 350px"><i class="fa fa-save"></i> Save</button>
      </div>
    </form>


  <script src="../js/script.js"></script>
</body>

</html>