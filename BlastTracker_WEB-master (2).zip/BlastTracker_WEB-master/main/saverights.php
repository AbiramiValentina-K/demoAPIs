<?php
require_once('../include/auth.php');
  $menuId = '';

$id = $_POST['roleId'];
$action = $_POST['action'];
$menuRights = $_POST['menuRights'];
$menuId = $_POST['menuId'];
$data1 = [];
$keys = array_keys($menuId);
$roleId = implode(',',$id);
$data = [];

        for ( $i = 0; $i < count($menuId); $i++ ) {
            $data = [ "menuId" => $menuId[$i],
                    "roleId" =>  $roleId,
                    "rights" =>  1 ];
        array_push($data1,$data);
        }


$ch = require "../include/init_curl.php";
if($action=='new'){
   //delete existing saved rights
     DeleteMenuRights($roleId);

    curl_setopt($ch, CURLOPT_URL, $url."menurights/addall/");
}
elseif($action=='edit'){
    curl_setopt($ch, CURLOPT_URL, $url."/menurights/".$_POST['userId']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");

}
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data1)); 


$response = curl_exec($ch);

$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
header("location: Rights.php?action=edit&roleid=".$roleId);

if ($status_code === 422) {
    
    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {
    
    echo "Unexpected status code: $status_code";
    var_dump($data);    
    exit;
}

function DeleteMenuRights($roleId)
{  
$ch = require "../include/init_curl.php";
var_dump(json_encode($_POST));
curl_setopt($ch, CURLOPT_URL, $url."menurights/".$roleId);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
$response = curl_exec($ch);

$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
$data = json_decode($response, true);

}
?>
