<?php
require_once('../include/auth.php');

$id = $_POST['materialId'];
$action = $_POST['action'];
$consumeType = $_POST['consumeType'];
echo $consumeType;
$ch = require "../include/init_curl.php";
if($action=='new'){
    curl_setopt($ch, CURLOPT_URL, $url."material/add/");
}
elseif($action=='edit'){
    curl_setopt($ch, CURLOPT_URL, $url."/material/".$_POST['materialId']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
}
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($_POST)); 


$response = curl_exec($ch);

$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
if($action=='new'){
    updatestocktable($data,$consumeType);
}
header("location: Material.php");

if ($status_code === 422) {
    
    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {
    
    echo "Unexpected status code: $status_code";
    var_dump($data);    
    exit;
}
function updatestocktable($data,$consumeType){
    $materialId =  $data['materialId'];
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."subContractor/all");
    $response = curl_exec($ch);
    curl_close($ch);
    $subCon = json_decode($response, true);
    $stockdata[]=NULL;
    $data1[]='';


    foreach($subCon as $data)
    {
        $tempdata =  [  "subConId" => $data['subConId'],
                        "materialId"=> $materialId,
                        "qty" => 0,
                        "nonConsumableQty" => 0,
                        "consumeType" => $consumeType
                        ];
        array_push($stockdata,$tempdata);
    }

    for ( $i = 0; $i < count($stockdata); $i++ ) {
        $row = $stockdata[$i];
     $ch = require "../include/init_curl.php";

    curl_setopt($ch, CURLOPT_URL, $url."stock/add/");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($row)); 
    $response = curl_exec($ch);

echo(json_encode($row));
    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
 
    }
    if ($status_code === 422) {
    
        echo "Invalid data: ";
        print_r($data["errors"]);
        exit;
    }
    
    if ($status_code !== 201) {
        
        echo "Unexpected status code: $status_code";
        var_dump($data);    
        exit;
    }
}

?>
