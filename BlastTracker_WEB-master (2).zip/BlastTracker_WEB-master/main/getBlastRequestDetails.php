<?php
require_once('../include/auth.php');

$blastingHeaderId = $_GET['id'];



$ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."blastingRequest/details/".$blastingHeaderId);
  $response = curl_exec($ch);
  curl_close($ch);
  $blastrequest = json_decode($response, true);
  $myJSON = [];
  $materialList =[];

//get material Id from stock
  foreach($blastrequest as $item){
    $ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."stock/".$item['stockId']);
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);
  $data1 = ["materialId" =>  $data['materialId']
            ] ;
  array_push($materialList,$data1);
}

//get material Id from Description
$materialwithdesc =[];
foreach($materialList as $item)
{
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."material/".$item['materialId']);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    $data1 = ["materialId" =>  $data['materialId'],
    "materialDescription" => $data['materialDescription']
    ] ;
  array_push($materialwithdesc,$data1);

}
//get materialDescription from Material using materialId
for ( $i = 0; $i < count($materialwithdesc); $i++ ) {
    $data = [ "materialId" => $materialwithdesc[$i]['materialId'],
               "materialDescription" => $materialwithdesc[$i]['materialDescription'],
               "stockId" =>  $blastrequest[$i]['stockId'],
               "qty" => $blastrequest[$i]['qtySupplied'],
               "qtyApproved" => $blastrequest[$i]['qtyApproved']
               ];
array_push($myJSON,$data);
}


echo json_encode($myJSON);
?>