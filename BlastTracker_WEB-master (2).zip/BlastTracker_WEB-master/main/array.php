<?php
$id = $_POST['roleId'];
$action = $_POST['action'];
$menuRights = $_POST['menuRights'];
$menuId = $_POST['menuId'];
$data1 = [];
$keys = array_keys($menuId);
$roleId = implode(',',$id);
$data = [];

       for ( $i = 0; $i < count($menuId); $i++ ) {
            $data = [ "menuId" => $menuId[$i],
                       "roleId" =>  $roleId,
                       "rights" =>  1 ];
        array_push($data1,$data);
        }
    

var_dump($menuId);
echo "<br>"; 
echo "<br><br><br><br>";



$final1 = json_encode($data1);
var_dump($final1);

?>