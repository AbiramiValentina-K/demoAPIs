
<?php
require_once('../include/auth.php');
require_once('../include/common.php');
$menuId1 = 7;
validateUserRights($menuId1,$_SESSION['SESS_ROLE_ID']);

$id = $_GET['id'];
$materialDescription = $_GET['materialDescription'];
$uom = $_GET['uom'];
$subConName = $_GET['subConName'];
$subConId = $_GET['subConId'];
$availableQty = $_GET['qty'];
$materialId = $_GET['materialId'];
$consumeType = $_GET['consumeType'];
$updatedQty = $_GET['updatedQty'];
$roleId = $_SESSION['SESS_ROLE_ID'];

?>

  
          <ol class="breadcrumb new-bg" style="width: 625px">
            <li class="breadcrumb-item text-white">Add Inventory</li>
          </ol>
      


    
  
    <form action="SaveStock.php" method="POST">
      <input type="hidden" name="stockId" value="<?php echo $id; ?>">
      <input type="hidden" name="materialId" value="<?php echo $materialId; ?>">
      <input type="hidden" name="subConId" value="<?php echo $subConId; ?>">
      <input type="hidden" name="consumeType" value="<?php echo $consumeType; ?>">
  
      <div class="row no-gutters">
        <div class="col-md-6 p-1">
        <div class="floating-label">    
        <input type="text" disabled class="floating-input" value="<?php echo $subConName; ?>" style="width: 300px" name="subConName" placeholder=" " >
        <label>Sub Contractor Name</label>             

        </div>
      </div>

      <div class="col-md-6 p-1">
        <div class="floating-label">    
        <input type="text" disabled class="floating-input" value="<?php echo $materialDescription; ?>" style="width: 300px" name="materialDescription" placeholder=" " >
        <label>Material Description</label>             

        </div>
      </div>

      <div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="text" disabled class="floating-input" id="oldQty" style="width: 300px" name="oldQty" value="<?php echo $availableQty; ?>" placeholder=" " required>
        <label>Available Qty</label>
        </div>
      </div>

      <div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="text" readonly  class="floating-input" style="width: 300px" name="uom" value="<?php echo $uom; ?>" placeholder=" " required>
        <label>UOM</label>
        </div>
      </div>

      <div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="number"  min="0" class="floating-input" id="newQty" style="width: 300px" name="newQty"placeholder=" "onkeyup="calcular()" onclick="calcular()" value="<?php echo $updatedQty;?>" required>
        <label>Enter Qty</label>
        </div>
      </div>
<div id="HeaderPart1">
<div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="number"  min="0" class="floating-input" id="approvedQty" style="width: 300px" name="approvedQty"placeholder=" " onkeyup="calcular()" required>
        <label>Approved Qty</label>
        </div>
      </div>

 </div>

 <?php if($_GET['consumeType'] == 'NC'){?>
        <div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="text" readonly  class="floating-input" id="totalQty" style="width: 300px" name="nonConsumableQty"  placeholder=" " required>
        <label>Current Total Qty</label>
        </div>
      </div>
    <?php
      } else { ?>
      <div class="col-md-6 p-1">
        <div class="floating-label">                 
        <input type="text" readonly  class="floating-input" id="totalQty" style="width: 300px" name="qty"  placeholder=" " >
        <label>Current Total Qty</label>
        </div>
      </div>
    <?php }  
       if ($roleId == 3) {
          $btnclass = "form-control btn btn-block btn-warning";
          $btnInnerValue = "Save & Approve";
        echo "<input type='hidden' name='status' value='status'>";
        } else {
          $btnclass = "form-control btn btn-block btn-primary";
          $btnInnerValue = "Save";
        } ?>
      
      <div class="row no-gutters d-flex justify-content-center form-group mt-6">
        <button type="submit" id="submit"  class="<?php echo $btnclass; ?>" style="max-width: 600px"><i class="fa fa-save"></i> <?php echo $btnInnerValue; ?></button>
      </div>
      

        <!-- <div class="row no-gutters d-flex justify-content-center form-group mt-6">
          <button type="submit" class="form-control btn btn-block btn-primary" style="width: 625px"><i class="fa fa-save"></i> Save</button>
        </div> -->
    </form>

    <script>

      $(document).ready(function(){

      var HeaderPart1 = document.getElementById("HeaderPart1");

      var roleId = <?php echo $roleId; ?>;
      
        if(roleId == 1){
        HeaderPart1.style.display = "none";
        }
      });

    function calcular() {
        var oldQty =parseInt(document.getElementById('oldQty').value,10);
        var newQty =parseInt(document.getElementById('newQty').value,10);
  

        document.getElementById('totalQty').value = oldQty + newQty;
        }
    </script>

  <script src="../js/script.js"></script>
</body>

</html>