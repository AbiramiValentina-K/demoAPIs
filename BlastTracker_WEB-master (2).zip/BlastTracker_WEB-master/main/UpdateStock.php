<?php
require_once('../include/common.php');

$stockId = $_GET['id'];
$qty = $_GET['qty'];
$blastingHeaderId = $_GET['HeaderId'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."stock/".$stockId);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
    $newstock = [
        "stockId" => $data['stockId'],
        "subConId" => $data['subConId'],
        "materialId" => $data['materialId'],
        "qty" =>  $data['qty'] + $qty
    ];
    saverecord("edit","stock",$stockId,$newstock);
    
 
    $ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."blastingRequest/details/".$blastingHeaderId);
  $response = curl_exec($ch);
  curl_close($ch);
  $blastrequest = json_decode($response, true);

$blastingRequestId = '';
var_dump(json_encode($blastrequest));
//get material Id from stock
  foreach($blastrequest as $bsr){
   
    if($bsr['stockId'] == $newstock['stockId']){$blastingRequestId = $bsr['blastingRequestId'];
        echo $blastingRequestId;
    deleterecord("delete","blastingRequest",$blastingRequestId);
    exit();
    

   }
}

?>

