<?php
  require_once('../include/init_curl.php');
  require_once('../include/auth.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?php echo $_SESSION['SESSS_TITLE'];?></title>

    <script src="../js/jquery.min.js"></script>  
    <script src="../js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" type="image/png" href="..\assets\icon.png">


  </head>
  <style>
  #orderTable {
        font-family: Arial, Helvetica, sans-serif;
        width: 100%;
        text-align: center;
        border: 1px solid;
        padding: 10px;
        border-radius:10px;
        box-shadow: 10px -20px 35px #888888;

      }
     
      
      #orderTable td, #orderTable th {
        border: 1px solid #ddd;
        padding: 8px;

      }
      
      #orderTable tr:nth-child(even){background-color: #f2f2f2;}
      
      #orderTable tr:hover {background-color: #ddd;}
      
      #orderTable th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: center;
        background-color: #61A2FB;
        color: white;
      }

      li{
        list-style-type: none;
      }
</style>
  <body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

    <!-- <?php include_once('../include/footer.php'); ?> -->
    <script src="../js/script.js"></script>
  </body>
</html>