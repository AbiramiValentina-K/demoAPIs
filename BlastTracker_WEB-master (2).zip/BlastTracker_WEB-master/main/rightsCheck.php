<?php

require_once('../include/auth.php');
$subConId = $_SESSION['SESS_SUBCON_ID'];

$ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."/stock/lowStock/".$subConId);
  $response = curl_exec($ch);
  curl_close($ch);
  $stock = json_decode($response, true);
  $data[] =''; 
  for ( $i = 0; $i < count($stock); $i++ )
  {
  $ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."/material/".$stock[$i]['materialId']);
  $response = curl_exec($ch);
  curl_close($ch);
  $materialList = json_decode($response, true);
  $stock[$i]["materialDescription"]=$materialList['materialDescription'];

  }

// Send in JSON encoded form
$myJSON = json_encode($stock);
echo $myJSON;
?>