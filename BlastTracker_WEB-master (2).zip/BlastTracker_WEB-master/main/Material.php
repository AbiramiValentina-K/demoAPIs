<?php
  require_once('../include/init_curl.php');
  require_once('../include/auth.php');
  require_once('../include/common.php');
  $menuId = 4;
  validateUserRights($menuId,$_SESSION['SESS_ROLE_ID']);  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Material |  <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
  </head>

  <body>
    <?php include_once('../include/navbar.php'); ?>
    <?php include_once('../include/sidebar.php'); ?>
    	
    <div class="main container">

      <div class="row no-gutters">
        <div class="col p-1">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
              <li class="breadcrumb-item active" aria-current="page">Material</li>
            </ol>
          </nav>
        </div>
      </div>

      <div class="row no-gutters">
        <div class="col-3 p-1">
        <a href="MaterialControl.php?action=new" role="button" style="width:100px" class="form-control btn btn-primary"><b>+ </b>Material </a>

          </div>
        <div class="col-9 p-1">
          <input type="text" name="search" id="search" class="form-control" placeholder="Search in Material">
        </div>
      </div>
	  
      <div class="row no-gutters p-1">
        <div  class="table-responsive" id="userTable">
          <table class="table">
            <thead>
              <tr>
                <th width="50%">Material Description</th>
                <th width="40%">UOM</th>
                <th width="10%">Action</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $ch = require "../include/init_curl.php";

				       curl_setopt($ch, CURLOPT_URL, $url."material/all");
                $response = curl_exec($ch);
                curl_close($ch);
                $data = json_decode($response, true);
                foreach($data as $item) {
              ?>

			        <tr class="record">
                <td><?php echo $item['materialDescription']; ?></td>
                <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."uom/".$item['uomId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $data = json_decode($response, true);

                ?>
                <?php
                if($item['uomId']==$data['uomId'])
                {?>
                <td><?php echo $data['fullName']; }?></td>
                <td class="actions">
                  <a href="MaterialControl.php?action=edit&id=<?php echo $item['materialId']; ?>" title="Edit Material details">
                    <button class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></button>
                  </a>
                  <a href="deletematerial.php?id=<?php echo $item['materialId']; ?>" class="delbutton" onclick="return  confirm('Are you sure want to delete? Click on Cancel button to Abort!')" title="Delete Material">
                    <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                  </a>
			          </td>
              </tr>

			        <?php
				        }
              ?>
        
            </tbody>
          </table>
        </div>
      </div>
    </div>
   
    <?php include_once('../include/footer.php'); ?>

    <script>
      function filterTable(event) {
        var filter = event.target.value.toUpperCase();
        var rows = document.querySelector("#userTable tbody").rows;
      
        for (var i = 0; i < rows.length; i++) {
          var firstCol = rows[i].cells[0].textContent.toUpperCase();
          var secondCol = rows[i].cells[1].textContent.toUpperCase();
          if (firstCol.indexOf(filter) > -1 || secondCol.indexOf(filter) > -1)
            rows[i].style.display = "";
          else
            rows[i].style.display = "none";
        }
      }

      document.querySelector('#search').addEventListener('keyup', filterTable, false);
    </script>
    <script src="../js/script.js"></script>

  </body>
</html>