<?php
require_once('../include/init_curl.php');
//Start session
session_start();
require_once('../include/common.php');
$menuId1 = 3;
validateUserRights($menuId1, $_SESSION['SESS_ROLE_ID']);

if ($_GET['action'] == 'new') {
  $roleId1 = $_SESSION['SESS_ROLE_ID'];
  $menuId = '';
}
if ($_GET['action'] == 'edit') {
  $roleId1 = $_GET['roleid'];
  curl_setopt($ch, CURLOPT_URL, $url . "menurights/role/" . $roleId1);
  $menuId[] = '';
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);

  foreach ($data as $value) {
    array_push($menuId, $value['menuId']);
  }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rights | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/all.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">

</head>

<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">

    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item active" aria-current="page">Rights</li>
          </ol>
        </nav>
      </div>
    </div>

    <script>
      function load_rights() {
        $var = document.getElementById("roleId").value;
        window.location = "Rights.php?roleid=" + $var + "&action=edit";
      }
    </script>
    <br>
    <form action="saverights.php" id="rightsform" method="post">
      <input type="hidden" name="action" value="new">


        <div class="col-md-6 p-1">
        <div class="floating-label"> 
          <select class="floating-select" name="roleId[]" id="roleId" onchange=load_rights() required>
            <?php
            $ch = require "../include/init_curl.php";

            curl_setopt($ch, CURLOPT_URL, $url . "userrole/all");
            $response = curl_exec($ch);
            curl_close($ch);
            $data = json_decode($response, true);
            foreach ($data as $row) {

            ?>

              <option value="<?php echo $row['roleId'] ?>" <?php if ($roleId1 == $row['roleId']) {
                                                              echo "selected";
                                                            } ?>><?php echo $row['roleName'] ?></option>

            <?php
            }
            ?>
          </select>
          <label>User Role</label>
        </div>
      </div>

      <div class="row no-gutters p-1">
        <div class="table-responsive" id="userTable">
          <table class="table">
            <thead>
              <tr>
                <th width="30%">Main Menu</th>
                <th width="30%">Sub Menu</th>
                <th width="10%"><input type="checkbox" id="selectall" /> Rights </th>
              </tr>
            </thead>

            <tbody>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "menu/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $item) {;
              ?>


                <tr class="record">
                  <td><?php if ($item['mainMenu'] == 1) {
                        echo $item['menuName'];
                      } ?>
                  </td>
                  <td><?php if ($item['mainMenu'] == 0) {
                        echo $item['menuName'];
                      } ?>
                  </td>
                  <td>
                    <?php if ($item['menuName'] == "Master") { ?>
                      <input type="checkbox" name="menuId[]" class="case menu_one" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                  if ($value == $item['menuId']) {
                                                                                                    echo "checked";
                                                                                                  }
                                                                                                } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <?php if ($item['mainId'] == 1) {
                    ?>
                      <input type="checkbox" name="menuId[]" class="case submenu_one" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                    if ($value == $item['menuId']) {
                                                                                                      echo "checked";
                                                                                                    }
                                                                                                  } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <!-- transaction -->
                    <?php if ($item['menuName'] == "Transaction") { ?>
                      <input type="checkbox" name="menuId[]" class="case menu_two" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                  if ($value == $item['menuId']) {
                                                                                                    echo "checked";
                                                                                                  }
                                                                                                } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <?php if ($item['mainId'] == 6) {
                    ?>
                      <input type="checkbox" name="menuId[]" class="case submenu_two" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                    if ($value == $item['menuId']) {
                                                                                                      echo "checked";
                                                                                                    }
                                                                                                  } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <!-- endtransaction -->
                    <!-- repot -->
                    <?php if ($item['menuName'] == "Report") { ?>
                      <input type="checkbox" name="menuId[]" class="case menu_three" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                    if ($value == $item['menuId']) {
                                                                                                      echo "checked";
                                                                                                    }
                                                                                                  } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <?php if ($item['mainId'] == 10) {
                    ?>
                      <input type="checkbox" name="menuId[]" class="case submenu_three" id="menuId" <?php foreach ($menuId as $value) {
                                                                                                      if ($value == $item['menuId']) {
                                                                                                        echo "checked";
                                                                                                      }
                                                                                                    } ?> value=<?php echo $item['menuId'] ?>>
                    <?php
                    }
                    ?>
                    <!-- end report -->
                  </td>

                  <input type="hidden" name="menuRights[]" id="menuId" value=<?php echo $item['menuId'] ?>>
                  <!-- <input type="hidden" name="roleId[]" id="menuId" value=<?php echo $item['menuId'] ?>> -->
                </tr>

              <?php
              }
              ?>

            </tbody>
          </table>
        </div>
        <input name="submitmsg" type="submit" onclick="myFunction()" class="form-control btn btn-primary" value="Save" />

    </form>


  </div>



  <?php include_once('../include/footer.php'); ?>

  <script>
    // checkboxselect
    $("#selectall").click(function() {

      if (this.checked) {
        $(".case").each(function() {
          this.checked = true;
        });
      } else {
        $(".case").each(function() {
          this.checked = false;
        });
      }

    });

    $(".menu_one").click(function() {

      if (this.checked) {
        $(".submenu_one").each(function() {
          this.checked = true;
        });
      } else {
        $(".submenu_one").each(function() {
          this.checked = false;
        });
      }

    });

    $(".menu_two").click(function() {

      if (this.checked) {
        $(".submenu_two").each(function() {
          this.checked = true;
        });
      } else {
        $(".submenu_two").each(function() {
          this.checked = false;
        });
      }

    });

    $(".menu_three").click(function() {

      if (this.checked) {
        $(".submenu_three").each(function() {
          this.checked = true;
        });
      } else {
        $(".submenu_three").each(function() {
          this.checked = false;
        });
      }

    });
    // checkboxselect-end
  </script>

  <script>
    function filterTable(event) {
      var filter = event.target.value.toUpperCase();
      var rows = document.querySelector("#userTable tbody").rows;

      for (var i = 0; i < rows.length; i++) {
        var firstCol = rows[i].cells[0].textContent.toUpperCase();
        var secondCol = rows[i].cells[1].textContent.toUpperCase();
        if (firstCol.indexOf(filter) > -1 || secondCol.indexOf(filter) > -1)
          rows[i].style.display = "";
        else
          rows[i].style.display = "none";
      }
    }

    document.querySelector('#search').addEventListener('keyup', filterTable, false);
  </script>

  <script src="../js/script.js"></script>

</body>

</html>