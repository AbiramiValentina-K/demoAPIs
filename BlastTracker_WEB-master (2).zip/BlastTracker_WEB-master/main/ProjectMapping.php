<?php
require_once('../include/init_curl.php');
require_once('../include/auth.php');
require_once('../include/common.php');
$menuId = 4;
validateUserRights($menuId, $_SESSION['SESS_ROLE_ID']);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Project Mapping | <?php echo $_SESSION['SESSS_TITLE'];?></title>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  <script src="../facebox/src/facebox.js"></script>

  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="..//facebox/src/facebox.css">
  <!-- <link rel="stylesheet" href="css/font-awesome/font-awesome.min.css"> -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" type="image/png" href="..\assets\icon.png">
  <script>
    $.facebox.settings.closeImage = '../facebox/closelabel.png';
    $.facebox.settings.loadingImage = '../facebox/loading.gif';
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox()
    })
  </script>
</head>

<body>
  <?php include_once('../include/navbar.php'); ?>
  <?php include_once('../include/sidebar.php'); ?>

  <div class="main container">
    <div class="row no-gutters">
      <div class="col p-1">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li> -->
            <li class="breadcrumb-item"><a href="ProjectMapping.php">Project Mapping </a></li>
            <li class="breadcrumb-item active" aria-current="page"></li>
          </ol>
        </nav>
      </div>
    </div>
    <form action="SaveProject.php" method="POST">
    <div class="row no-gutters">

        <div class="col-md-3 p-1">
          <div class="floating-label">
            <select class="floating-select" name="locationId" required>
              <option value="" selected></option>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "location/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['locationId'] ?>"><?php echo $row['locationName'] ?></option>

              <?php
              }
              ?>

            </select>

            <label>Location</label>
          </div>
        </div>
        <div class="col-md-1 p-1">
        <a href="addLocation.php?action=new" rel="facebox" role="button"  class="form-control btn btn-primary"><b>+ </b>Add </a>
        </div>

        
    <div class="col-md-4 p-1">
        <div class="floating-label">      
        <input type="text" class="floating-input"  name="projectName"  value="" placeholder=" " required>
        <label>Project</label>
        </div>
      </div>

        </div>
        <input type="submit"  class="form-control btn btn-primary" style="width: 175px;">
        </form>

        <hr>
<form action="SaveProjectmapping.php" method="POST">
  <input type="hidden" name="action" value="new">
  <input type="hidden" name= "projectMappingId" value="0">
    <div class="row no-gutters">
        <div class="col-md-3 p-1">
          <div class="floating-label">
            <select class="floating-select" name="subConId" required>
              <option value="" selected></option>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "subContractor/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['subConId'] ?>"><?php echo $row['subConName'] ?></option>

              <?php
              }
              ?>

            </select>

            <label>Sub Contractor</label>
          </div>
        </div>


        <div class="col-md-1 p-1">
        <a href="SubCon.php" rel="facebox" role="button"  class="form-control btn btn-primary"><b>+ </b> Add </a>
        </div>

        <div class="col-md-4 p-1">
          <div class="floating-label">
            <select class="floating-select" name="locationId" id="locationId" onchange="loadProjectList()" required>
              <option value="" selected></option>
              <?php
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "location/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['locationId'] ?>"><?php echo $row['locationName'] ?></option>

              <?php
              }
              ?>

            </select>

            <label>Location</label>
          </div>
        </div>

        <div class="col-md-4 p-1">
          <div class="floating-label">
            <select class="floating-select" name="projectId" id="projectId" required>
              <option value="" selected></option>
              <?php
              if(isset($_POST['locationId'])){
              $ch = require "../include/init_curl.php";

              curl_setopt($ch, CURLOPT_URL, $url . "project/all");
              $response = curl_exec($ch);
              curl_close($ch);
              $data = json_decode($response, true);
              foreach ($data as $row) {

              ?>

                <option value="<?php echo $row['projectId'] ?>"><?php echo $row['projectName'] ?></option>

              <?php
              }}
              ?>

            </select>

            <label>Project Name</label>
          </div>
        </div>


<input type="submit"  class="form-control btn btn-primary" style="width: 175px;">
      </div>
        </form>
  <hr>
  <div class="row no-gutters p-1">
  
  <div class="table-responsive" id="location">
      <table class="table">
        <thead>
          <tr>
            <th width="30%">SubContractor Name</th>
            <th width="30%">Location Name</th>
            <th width="30%">Project Name</th>
          </tr>
        </thead>

        <tbody>
          <?php
          $ch = require "../include/init_curl.php";

          curl_setopt($ch, CURLOPT_URL, $url . "projectMapping/all");
          $response = curl_exec($ch);
          curl_close($ch);
          $projectMapping = json_decode($response, true);
          foreach ($projectMapping as $mapRow) {
          ?>

            <tr class="record">
            <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."subContractor/".$mapRow['subConId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $subContractor = json_decode($response, true);
                ?>
                <td><?php echo $subContractor['subConName']; ?></td>
                <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."location/".$mapRow['locationId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $location = json_decode($response, true);
                ?>
                <td><?php echo $location['locationName']; ?></td>
                <?php
                $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."project/".$mapRow['projectId']);
                $response = curl_exec($ch);
                curl_close($ch);
                $project = json_decode($response, true);
                ?>
                <td><?php echo $project['projectName']; ?></td>

            </tr>

          <?php
          }
          ?>

        </tbody>
      </table>
    </div>
  </div>
  </div>

  

  <?php include_once('../include/footer.php'); ?>
  <script src="../js/script.js"></script>
  <script>
    function loadProjectList(){
      var locationId = document.getElementById("locationId").value;


    var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {


        if (this.readyState == 4 &&
          this.status == 200) {


          var myObj = JSON.parse(this.responseText);

          var project = document.getElementById("projectId");
          project.innerHTML = "";

          for(i=0; i<myObj.length; i++){
          var option = document.createElement("option");
            option.text = myObj[i].projectName;
            option.value = myObj[i].projectId;
            project.add(option);
            }


        }
      };

      xmlhttp.open("GET", "getProject.php?id=" + locationId, true);

      xmlhttp.send();
    }
  </script>
</body>

</html>