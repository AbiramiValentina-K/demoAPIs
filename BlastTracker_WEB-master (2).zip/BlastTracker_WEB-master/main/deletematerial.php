<?php
require_once('../include/auth.php');
$id = $_GET['id'];

if (ValidateStock($id) == "true") {
    $message = "Material Exists in Stock Not Able to Delele";
    echo "<script type='text/javascript'> 
    alert ('" . $message . "');
    window.open('material.php"."','_self');
    </script>";
} elseif (ValidateStock($id) == "false") {

    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url . "/material/" . $id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode($response, true);
    header("location: material.php");
    $response = curl_exec($ch);



    if ($status_code === 422) {
    
        echo "Invalid data: ";
        print_r($data["errors"]);
        exit;
    }
    
    if ($status_code !== 201) {
    
        echo "Unexpected status code: $status_code";
        var_dump($data);
        exit;
    }
}



function ValidateStock($id)
{

    $ch = require "../include/init_curl.php";
    $result = 'false';
    curl_setopt($ch, CURLOPT_URL, $url . "subContractor/all");
    $sresponse = curl_exec($ch);
    curl_close($ch);
    $subContractor = json_decode($sresponse, true);

    foreach ($subContractor as $item) {
        $ch = require "../include/init_curl.php";
        curl_setopt($ch, CURLOPT_URL, $url . "stock/material/" . $id . "/" . $item['subConId']);

        $response = curl_exec($ch);
        curl_close($ch);
        $stock = json_decode($response, true);
        if (count($stock) > 0) {
            $result = 'true';
        }
    }

    return $result;
}
