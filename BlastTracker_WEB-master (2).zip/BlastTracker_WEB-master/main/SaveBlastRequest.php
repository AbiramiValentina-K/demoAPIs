<?php
require_once('../include/auth.php');
require_once('../include/common.php');

$date = $_POST['date'];
$shift = $_POST['shift'];
$tunnelFace = $_POST['tunnelFace'];
$action = $_POST['action'];
$blastingHeaderId = $_POST['blastingHeaderId'];
$subConId = $_POST['subConId'];
$blastingRequestId = $_POST['blastingRequestId'];
$orderId = $_POST['orderId'];
$chainageFrom = $_POST['chainageFrom'];
$chainageTo = $_POST['chainageTo'];
$supportClassId = $_POST['supportClassId'];
$excavationMethodId = $_POST['excavationMethodId'];
$userId = $_POST['userId'];
$roleId = $_POST['roleId'];

                                    //generate order id automatic

                                if($action=='new'){
                                $ch = require "../include/init_curl.php";
                                curl_setopt($ch, CURLOPT_URL, $url."settings/all");
                                $response = curl_exec($ch);
                                curl_close($ch);
                                $data = json_decode($response, true);
                                foreach($data as $row)
                                $orderIdLatest = $row['orderIdLatest']+1;
                                $settingsId = $row['settingsId'];
                                $orderIdFront = $row['orderIdFront'];
                                $stockTransferIdLatest = $row['stockTransferIdLatest'];
                                $stockTransferIdFront = $row['stockTransferIdFront'];
                                $orderId = $row['orderIdFront'].sprintf("%04s", $orderIdLatest);
                                $settingorderId = [
                                    "orderIdLatest" => $orderIdLatest,
                                    "settingsId" => $settingsId,
                                    "orderIdFront" => $orderIdFront,
                                    "stockTransferIdFront" => $stockTransferIdFront,
                                    "stockTransferIdLatest" => $stockTransferIdLatest
                                ];
                                $data = json_decode($response, true);
                                $ch = require "../include/init_curl.php";
                                curl_setopt($ch, CURLOPT_URL, $url."/settings/1");
                                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($settingorderId)); 
                                $response = curl_exec($ch);
                                $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                                curl_close($ch);
                                }

//array value
$stockId = $_POST['stockId'];
$qtySupplied = $_POST['qtySupplied'];

//array values convent into json format
$data1 = [];
$keys = array_keys($stockId);
$data = [];
$approvedQty = 0;
        for ( $i = 0; $i < count($stockId); $i++ ) {

        if(isset($_POST['qtyApproved'])){$approvedQty = $_POST['qtyApproved'][$i];}

               $data = [ "stockId" => $stockId[$i],
                    "qtySupplied" =>  $qtySupplied[$i],
                    "qtyApproved"=>$approvedQty,
                    "date" =>  $date,
                    "shift" => $shift,
                    "tunnelFaceId" => $tunnelFace,
                    "blastingHeaderId" => $blastingHeaderId,
                    "subConId" => $subConId,
                    "orderId" => $orderId,
                    "blastingRequestId" => $blastingRequestId,
                    "status" => "---",
                    "chainageFrom" => $chainageFrom,
                    "chainageTo" => $chainageTo,
                    "supportClassId" => $supportClassId,
                    "excavationMethodId" => $excavationMethodId,
                    "userId" => $userId

                ];

        array_push($data1,$data);
        }

$ch = require "../include/init_curl.php";

if($action=='new'){
    curl_setopt($ch, CURLOPT_URL, $url."blastingRequestHeader/add/");
}
elseif($action=='edit'){
    curl_setopt($ch, CURLOPT_URL, $url."/blastingRequestHeader/".$blastingHeaderId);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
}
foreach($data1 as $headerData){
    $validHaderData = $headerData;
    }
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($validHaderData)); 
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

$RequestHeaderData = json_decode($response, true);

$stockId = $_POST['stockId'];
$qtySupplied = $_POST['qtySupplied'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."blastingRequest/details/".$_POST['blastingHeaderId']);
$response = curl_exec($ch);
curl_close($ch);
$blastingRequest = json_decode($response, true);

for ( $i = 0; $i < count($data1); $i++ ) {
    if($action=='edit'){$data1[$i]["blastingHeaderId"] = $blastingHeaderId;}
    else{
    $data1[$i]["blastingHeaderId"]=$RequestHeaderData["blastingHeaderId"];}
    
}


$ch = require "../include/init_curl.php";
 if($action=='new'){
    
    curl_setopt($ch, CURLOPT_URL, $url."blastingRequest/addall/");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data1)); 
    $response = curl_exec($ch);
    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode($response, true);
    //update stock

    foreach($data1 as $qty){
        $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."stock/".$qty['stockId']);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    if( $data['consumeType'] == stockValidate($qty['stockId'])){
        $newstock = [
            "stockId" => $qty['stockId'],
            "subConId" => $qty['subConId'],
            "nonConsumableQty" => $data['nonConsumableQty'],
            "consumeType" => $data['consumeType'],
            "materialId" => $data['materialId'],
            "qty" =>  $data['qty'] - $qty['qtySupplied']
        ];
        saverecord("edit","stock",$qty['stockId'],$newstock);}
    }

}
elseif($action=='edit'){

    for ( $i = 0; $i < count($data1); $i++ ) {
        $data1[$i]["blastingRequestId"]=0;
    }
    
var_dump(json_encode($blastingRequest));
    
    foreach($blastingRequest as $item){
$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."/blastingRequest/".$item['blastingRequestId']);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);

    }

foreach($data1 as $item){
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."blastingRequest/add/");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($item)); 
    $response = curl_exec($ch);
    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode($response, true);
    if ($status_code === 422) {
    
        echo "Invalid data: ";
        print_r($data["errors"]);
        exit;
    }
    
    if ($status_code !== 201) {
        
        echo "Unexpected status code: $status_code";
        var_dump($data);    
        exit;
    }
  }

    //update stock qty
        $stockupdate = json_encode($data1);
        for ( $i = 0; $i < count($data1); $i++ ){
              $oldQty = 0;
            if(isset($blastingRequest[$i]['qtySupplied'])){
                $oldQty = $blastingRequest[$i]['qtySupplied'];
            }else{ $oldQty = 0;}
        $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."stock/".$data1[$i]['stockId']);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);

var_dump(json_encode($data));
$blsteEditQty = 0;
if($roleId == 2){
    $blsteEditQty = $data['qty'] + $blastingRequest[$i]['qtySupplied']  - $data1[$i]['qtySupplied'];
}
$siteEnggApproveQty = 0;
if($roleId == 3){
 $siteEnggApproveQty = $data['qty']  + ($data1[$i]['qtySupplied'] - $data1[$i]['qtyApproved']);
// $siteEnggApproveQty = $data1[$i]['qtySupplied'] - $data1[$i]['qtyApproved'];
}

    if( $data['consumeType'] == stockValidate($data1[$i]['stockId'])){
        $newstock = [
            "stockId" => $data1[$i]['stockId'],
            "subConId" => $data['subConId'],
            "nonConsumableQty" => $data['nonConsumableQty'],
            "consumeType" => $data['consumeType'],
            "materialId" => $data['materialId'],
            "qty" =>  $blsteEditQty +  $siteEnggApproveQty
        ];

        saverecord("edit","stock",$data1[$i]['stockId'],$newstock);
    }
    }
    }

    $message ='';
if( $action == 'new'){
    
        $message = "Order Created Sucessfully Order Id is = ".$orderId;
}elseif ($action = 'edit'){
    $message = "Your Order Id = ".$orderId." Updated";
}
        echo "<script type='text/javascript'> 
            alert ('".$message."');
		    window.open('BlastRequestList.php"."','_self');
        
        </script>";
    
function stockValidate($stockId){
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."stock/".$stockId);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    $result = $data['consumeType'];
    return $result;
    }


?>