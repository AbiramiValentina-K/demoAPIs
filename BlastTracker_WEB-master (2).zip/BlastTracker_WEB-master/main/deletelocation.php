<?php
require_once('../include/auth.php');
$id = $_GET['id'];
$ch = require "../include/init_curl.php";

curl_setopt($ch, CURLOPT_URL, $url."/location/".$id);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
echo $url."/project/".$id;
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);
header("location: Location.php");

if ($status_code === 422) {
    
    echo "Invalid data: ";
    print_r($data["errors"]);
    exit;
}

if ($status_code !== 201) {
    
    echo "Unexpected status code: $status_code";
    var_dump($data);    
    exit;
}

?>
