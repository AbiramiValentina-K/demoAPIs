<?php
require_once('../include/auth.php');

$stockTransferHeaderId = $_GET['id'];



$ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestDetails/details/".$stockTransferHeaderId);
  $response = curl_exec($ch);
  curl_close($ch);
  $stockrequest = json_decode($response, true);
  $myJSON = [];
  $materialList =[];

//get material Id from stock
  foreach($stockrequest as $item){
    $ch = require "../include/init_curl.php";
  curl_setopt($ch, CURLOPT_URL, $url."stock/".$item['stockId']);
  $response = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($response, true);
  $data1 = ["materialId" =>  $data['materialId'],
            ] ;
  array_push($materialList,$data1);
}

//get material Id from Description
$materialwithdesc =[];
foreach($materialList as $item)
{
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."material/".$item['materialId']);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    $data1 = ["materialId" =>  $data['materialId'],
    "materialDescription" => $data['materialDescription']
    ] ;
  array_push($materialwithdesc,$data1);

}
//get materialDescription from Material using materialId
for ( $i = 0; $i < count($materialwithdesc); $i++ ) {
    $data = [ "materialId" => $materialwithdesc[$i]['materialId'],
               "materialDescription" => $materialwithdesc[$i]['materialDescription'],
               "stockId" =>  $stockrequest[$i]['stockId'],
               "qty" => $stockrequest[$i]['qty'],
               "approvedQty" => $stockrequest[$i]['approvedQty'],
            "stockTransferRequestDetailsId"=>$stockrequest[$i]['stockTransferRequestDetailsId'] 
              ];
array_push($myJSON,$data);
}


echo json_encode($myJSON);
?>