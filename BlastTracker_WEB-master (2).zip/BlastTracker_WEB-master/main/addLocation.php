
<?php require_once('../include/auth.php');
  require_once('../include/common.php');
  $menuId = 2;
  validateUserRights($menuId,$_SESSION['SESS_ROLE_ID']);  
?>
  
          <ol class="breadcrumb" style="width: 500px">
            <li class="breadcrumb-item"  ><a href="#">Location</a></li>
          </ol>
      
          <form action="saveLocation.php" method="POST">
            <input type="hidden" name="locationId" value="0">
            <div class="row no-gutters">
              <div class="col-md-6 p-1">
                <div class="floating-label">
                  <input type="text" class="floating-input" name="locationName" style="width: 350px"  value="" placeholder=" " required>
                  <label>Location</label>
                </div>

              </div>
        </div>
            <div class="row no-gutters d-flex justify-content-center form-group mt-3">
              <button type="submit" class="form-control btn btn-block btn-info" style="max-width: 175px"><i class="fa fa-save"></i> Save</button>
            </div>
          </form>
        </div>
        </form>


  <script src="../js/script.js"></script>
</body>

</html>