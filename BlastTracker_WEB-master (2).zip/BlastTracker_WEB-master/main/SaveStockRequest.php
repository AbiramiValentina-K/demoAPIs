<?php
require_once('../include/auth.php');
require_once('../include/common.php');

$date = $_POST['date'];
$action = $_POST['action'];
$stockTransferRequestHeaderId = $_POST['stockTransferRequestHeaderId'];
$subConId =     $_POST['subConId'];
$fromSubConId = $_POST['fromSubConId'];
$stockRequestId = $_POST['stockRequestId'];
$orderId = $_POST['orderId'];
$userId = $_POST['userId'];
$roleId = $_POST['roleId'];
$remarks = $_POST['remarks'];
$materialId = $_POST['materialId'];

$status = '';
if($roleId == 3){$status = "Approved & Sipping";}
else{$status="---";}

                                    //generate order id automatic

                                if($action=='new'){
                                $ch = require "../include/init_curl.php";
                                curl_setopt($ch, CURLOPT_URL, $url."settings/all");
                                $response = curl_exec($ch);
                                curl_close($ch);
                                $data = json_decode($response, true);
                                foreach($data as $row)
                                $settingsId = $row['settingsId'];
                                $orderIdLatest = $row['orderIdLatest'];
                                $orderIdFront = $row['orderIdFront'];
                                $stockTransferIdLatest = $row['stockTransferIdLatest']+1;
                                $stockTransferIdFront = $row['stockTransferIdFront'];
                                $orderId = $row['stockTransferIdFront'].sprintf("%04s", $stockTransferIdLatest);
                                $settingorderId = [
                                    "orderIdLatest" => $orderIdLatest,
                                    "settingsId" => $settingsId,
                                    "orderIdFront" => $orderIdFront,
                                    "stockTransferIdFront" => $stockTransferIdFront,
                                    "stockTransferIdLatest" => $stockTransferIdLatest
                                ];
                                $data = json_decode($response, true);
                                $ch = require "../include/init_curl.php";
                                curl_setopt($ch, CURLOPT_URL, $url."/settings/1");
                                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($settingorderId)); 
                                $response = curl_exec($ch);
                                $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                                curl_close($ch);
                                }

//array value
$stockId = $_POST['stockId'];
$qty = $_POST['qty'];


//array values convent into json format
$data1 = [];
$keys = array_keys($stockId);
$data = [];
$approvedQty = 0;
        for ( $i = 0; $i < count($stockId); $i++ ) {

        if(isset($_POST['approvedQty'])){$approvedQty = $_POST['approvedQty'][$i];}

               $data = [ "stockId" => $stockId[$i],
                    "qty" =>  $qty[$i],
                    "approvedQty" => $approvedQty,
                    "date" =>  $date,
                    "stockTransferRequestHeaderId" => $stockTransferRequestHeaderId,
                    "subConId" => $subConId,
                    "orderId" => $orderId,
                    "stockRequestId" => $stockRequestId,
                    "status" => $status,
                    "modifiedBy" => $userId,
                    "userId" => $userId,
                    "remarks"=>$remarks,
                    "fromSubConId" => $fromSubConId,
                    "materialId" => $materialId[$i]

                ];

        array_push($data1,$data);
        }

$ch = require "../include/init_curl.php";

if($action=='new'){
    curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestHeader/add/");
}
elseif($action=='edit'){
    curl_setopt($ch, CURLOPT_URL, $url."/stockTransferRequestHeader/".$stockTransferRequestHeaderId);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
}
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data1[0])); 
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);

$stockId = $_POST['stockId'];
$qty = $_POST['qty'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestDetails/details/".$_POST['stockTransferRequestHeaderId']);
$response = curl_exec($ch);
curl_close($ch);
$stockRequestDetails = json_decode($response, true);

for ( $i = 0; $i < count($data1); $i++ ) {
    $data1[$i]["stockTransferRequestHeaderId"]=$RequestHeaderData["stockTransferRequestHeaderId"];
}



$ch = require "../include/init_curl.php";
 if($action=='new'){
    
    foreach($data1 as $item){
        saverecord("new","stockTransferRequestDetails",'',$item);
    }
}
elseif($action=='edit'){

    for ( $i = 0; $i < count($data1); $i++ ) {
        $data1[$i]["stockTransferRequestDetailsId"]=0;
    }
    
    
    foreach($stockRequestDetails as $item){
$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."/stockTransferRequestDetails/".$item['stockTransferRequestDetailsId']);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode($response, true);

    }

foreach($data1 as $item){
    $ch = require "../include/init_curl.php";
    curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestDetails/add/");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($item)); 
    $response = curl_exec($ch);
    $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode($response, true);

    if($roleId == 3){

                    //update stock qty
                    $ch = require "../include/init_curl.php";
                    $url = $url."stock/all/".$fromSubConId; 
                    curl_setopt($ch, CURLOPT_URL, $url);
                    $response = curl_exec($ch);
                    curl_close($ch);
                    $data = json_decode($response, true);
                   foreach($data as $newform){
                  if($newform['materialId']==$item['materialId']){
                          $newstock = [
                              "stockId" => $newform['stockId'],
                              "subConId" => $item['fromSubConId'],
                              "nonConsumableQty" => $newform['nonConsumableQty'],
                              "consumeType" => $newform['consumeType'],
                              "materialId" => $newform['materialId'],
                              "qty" =>  $newform['qty'] - $item['approvedQty']
                          ];
                        //   saverecord("edit","stock",$stock['stockId'],$newstock);
                        $ch = require "../include/init_curl.php";
                        curl_setopt($ch, CURLOPT_URL, $url."stock/".$newform['stockId']);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($newstock)); 
                        $response = curl_exec($ch);
                        $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                        curl_close($ch);
                        $data = json_decode($response, true);
                        }
                
                      

                  } 
    }

  }

  
}

    $message ='';
if( $action == 'new'){
    
        $message = "Stock Request Created Sucessfully Order Id is = ".$orderId;
}elseif ($action = 'edit'){
    $message = "Your Order Id = ".$orderId." Updated";
}
        echo "<script type='text/javascript'> 
            alert ('".$message."');
		    window.open('StockTransferList.php"."','_self');
        
        </script>";
    

function updateStock(){
   
    }
?>