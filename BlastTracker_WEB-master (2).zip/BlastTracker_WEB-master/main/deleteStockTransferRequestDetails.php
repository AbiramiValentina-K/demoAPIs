<?php
require_once('../include/auth.php');
require_once('../include/common.php');

$id = $_GET['id'];

deleterecord("delete","stockTransferRequestDetails",$id);
  

?>

