<?php
require_once('../include/common.php');

$id = $_GET['id'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestHeader/".$id);
$response = curl_exec($ch);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);


    $RequestHeaderData["status"]="Approved";

    $orderId = $RequestHeaderData["orderId"];


$ch = require "../include/init_curl.php";

    curl_setopt($ch, CURLOPT_URL, $url."/stockTransferRequestHeader/".$id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($RequestHeaderData)); 
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);

    
        $message = "Your Request Order Id  = ".$orderId . " Successfully Approved";
        echo "<script type='text/javascript'> 
            alert ('".$message."');
		    window.open('StockTransferList.php"."','_self');
        
        </script>"
?>