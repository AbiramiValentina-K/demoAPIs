<?php
require_once('../include/common.php');

$id = $_GET['id'];
$subConId = $_GET['subConId'];

$ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestDetails/details/".$id);
$response = curl_exec($ch);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);

foreach($RequestHeaderData as $item){
    //update stock qty
    $ch = require "../include/init_curl.php";
    $url = $url."stock/all/".$subConId; 
    curl_setopt($ch, CURLOPT_URL, $url);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    foreach($data as $newform){
    if($newform['materialId']==$item['materialId']){
            $newstock = [
                "stockId" => $newform['stockId'],
                "subConId" =>  $newform['subConId'],
                "materialId" => $newform['materialId'],
                "qty" =>  $newform['qty'] + $item['approvedQty']
            ];
        $ch = require "../include/init_curl.php";
        curl_setopt($ch, CURLOPT_URL, $url."stock/".$newform['stockId']);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($newstock)); 
        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $data = json_decode($response, true);

        }
        
    }
    } 

    $ch = require "../include/init_curl.php";
curl_setopt($ch, CURLOPT_URL, $url."stockTransferRequestHeader/".$id);
$response = curl_exec($ch);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);


    $RequestHeaderData["status"]="Received";

    $orderId = $RequestHeaderData["orderId"];


$ch = require "../include/init_curl.php";

    curl_setopt($ch, CURLOPT_URL, $url."/stockTransferRequestHeader/".$id);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($RequestHeaderData)); 
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$RequestHeaderData = json_decode($response, true);
    
        $message = "Material Received and Update to Stock";
        echo "<script type='text/javascript'> 
            alert ('".$message."');
		    window.open('StockTransferList.php"."','_self');
        
        </script>"
    

        

?>

<?php

   
    ?>