<?php
if($_SESSION['SESS_ROLE_ID'] != 5 && $_SESSION['SESS_ROLE_ID'] != 3)
{ $subConId = $_SESSION['SESS_SUBCON_ID'];}
else {$subConId='all';}
  ?>
<style>
  .sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 20px;
    color: #ffffff;
    display: block;
    transition: 0.3s;
    white-space: nowrap;
}
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    overflow-x: hidden;
    padding-top: 60px;
    transition: 0.5s;
    background-color: rgb(0 39 117);
    list-style: none;
}
</style>

<link rel="stylesheet" href="../css/all.css">


<div id="sideBar" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeSideBar()">&times;</a>
 
  <a href="#" target="_blank"><img style="margin-left:40px" src="../assets/icon.png" class="rounded" alt="Logo" target="_blank" width="65px"></a>
  <i class="fa-duotone fa-train-tunnel"></i>
  <?php
                $ch = require "../include/init_curl.php";
               
                $sroleId = $_SESSION['SESS_ROLE_ID'];
                curl_setopt($ch, CURLOPT_URL, $url."menurights/role/".$sroleId);
                $smenuId[] ='';
                $sresponse = curl_exec($ch);
                curl_close($ch);
                $sdata = json_decode($sresponse, true);
                
                foreach($sdata as $svalue){
                  array_push ($smenuId,$svalue['menuId']);
              }

              $ch = require "../include/init_curl.php";

                curl_setopt($ch, CURLOPT_URL, $url."menu/all");
                $sresponse = curl_exec($ch);
                curl_close($ch);
                $sdata = json_decode($sresponse, true);
                foreach($sdata as $sitem)
 {
 foreach ($smenuId as $svalue){if( $svalue==$sitem['menuId']){
  if ($sitem['mainMenu']==1){  echo "</ul>";?>
                 
    <a href="<?php echo "#".$sitem['menuName'];?>" data-toggle="collapse"><i class="<?php echo $sitem['faIcon'];?>"></i> <?php echo $sitem['menuName'];?></a>
    
      <?php echo "<ul id=".$sitem['menuName']." class=".'"'."collapse list-unstyled".'">';
    } 
    elseif ($sitem['mainMenu']==0){?>
        <li><a href=<?php 
        if($sitem['menuName'] == 'Inventory'){
        echo $sitem['navigateUrl'].$subConId;
      }else{echo $sitem['navigateUrl'];}
        
        ?>><i class="<?php echo $sitem['faIcon'];?>"></i><?php echo " ". $sitem['menuName'];?></a></li>
    
        <?php } 
}  
 }} 
    
?>

  
   <!-- <a href=#Maser data-toggle="collapse"><i class="fa fa-user"></i> Maser</a>
  <ul id=Maser class="collapse list-unstyled">
     <li><a href=user.php>User</a></li>
    <li><a href=Rights.php>Rights</a></li>
    <li><a href=Project.php>Project</a></li>
    <li><a href=Inventory.php>Inventory</a></li> </ul>
  <a href=#Trnsaction data-toggle="collapse"><i class="fa fa-file-text"></i> Trnsaction</a>
  <ul id=Trnsaction class="collapse list-unstyled">
  <li><a href=Order.php>Order</a></li>
  <li><a href=CreateOrder.php>Create Order</a></li>
  <li><a href=ReturnOrder.php>Return Order</a></li>  </ul>
  
<a href=#Report data-toggle="collapse"><i class="fa fa-print"></i> Report</a>
<ul id=Report class="collapse list-unstyled">

  <li><a href=inventoryreport.php>Inventory Report</a></li>
   </ul>
 -->


   

     

</div>



<script>  
  function openSideBar() {
    document.getElementById("sideBar").style.width = (window.innerWidth <= 480)?"100vw":"250px";
  }

  function closeSideBar() {
    document.getElementById("sideBar").style.width = "0";
  }
</script>