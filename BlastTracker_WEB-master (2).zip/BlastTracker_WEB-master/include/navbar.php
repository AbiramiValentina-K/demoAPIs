<link rel="icon" type="image/png" href=".\assets\icon.png">
<body>
  

<?php
  require_once('../include/init_curl.php');
?>
<style>
  .bg-dark {
    background-color: #00194C!important;
}
.navbar-light .navbar-brand {
    color: rgb(255 255 255);
}
.navbar-light .navbar-nav .nav-link {
    color: rgb(255 255 255);
}
</style>
<nav class="navbar navbar-expand navbar-light bg-dark justify-content-between">
  <div>
    <a class="navbar-brand" onclick="openSideBar()"  href="javascript:void(0);">☰</a>
    <a class="navbar-brand" href="../main/index.php"><img src="../assets/icon.png" class="logo" alt="Logo"><span class="excess"> Blast Tracker</span></a>
  </div>
   
  <div>
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="javascript:void(0);">Hi,  <?php echo $_SESSION['SESS_FIRST_NAME'];?></a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li> -->
      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-user"></i>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li> -->
      <li class="nav-item">
        <a class="nav-link" href="#"><span class="excess"><?php echo date('D')." ".date('d-M-Y'); ?></span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../index.php"><i class="fa fa-sign-out"></i><span class="excess"> Logout</span></a>
      </li>
    </ul>
  </div>
</nav>
</body>


   