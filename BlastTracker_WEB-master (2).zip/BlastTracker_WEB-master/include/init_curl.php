<?php


/**
 * DO NOT CHECK THIS INTO SOURCE CODE CONTROL IF IT CONTAINS AN ACCESS TOKEN - SEE README FOR MORE DETAILS
 */
// $url = "http://129.154.47.8:8083/api/";
$url = "http://localhost:8083/api/";
$headers = [
    "User-Agent: Blaster Requesst Client API",
    "Content-Type: application/json"
 
];

$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_RETURNTRANSFER => true
]);

return $ch;
?>
