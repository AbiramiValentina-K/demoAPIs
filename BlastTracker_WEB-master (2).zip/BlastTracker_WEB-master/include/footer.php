<footer class="container-fluid row mt-2">
  <div class="col-md-6 text-center">
    <a href="#" target="_blank" style="text-decoration:none;">L&T</a> &copy;<?php echo date('Y') ?>
  </div>
  <div class="col-md-6 text-center">
    Designed by <a href="https://graspear.com" target="_blank">Graspear Solutions</a>
  </div>
</footer>