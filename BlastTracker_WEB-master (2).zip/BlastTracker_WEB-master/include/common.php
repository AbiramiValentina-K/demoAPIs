<?php
function saverecord($action,$api,$id,$array){
    $ch = require "../include/init_curl.php";
        if($action=='new'){
            curl_setopt($ch, CURLOPT_URL, $url."/".$api."/add");
        }
        elseif($action=='edit'){
            curl_setopt($ch, CURLOPT_URL, $url."/".$api."/".$id);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($array)); 
        $response = curl_exec($ch);
        
        $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $data = json_decode($response, true);
        return $data;
    }
    function deleterecord($action,$api,$id){
        if ($action == 'delete'){
        $ch = require "../include/init_curl.php";
        curl_setopt($ch, CURLOPT_URL, $url."/".$api."/".$id);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $data = json_decode($response, true);
        
        if ($status_code === 422) {
            
            echo "Invalid data: ";
            print_r($data["errors"]);
            exit;
        }
        
        if ($status_code !== 201) {
            
            echo "Unexpected status code: $status_code";
            var_dump($data);    
            exit;
        }
}}

function validateUserRights($menuId,$sroleId ){
    $ch = require "../include/init_curl.php";
    $menuId1 = $menuId;
                 
    $sroleId1 = $sroleId;
    curl_setopt($ch, CURLOPT_URL, $url."menurights/uservalidate/".$menuId1."/".$sroleId1);
    $smenuId[] ='';
    $sresponse = curl_exec($ch);
    curl_close($ch);
    $sdata = json_decode($sresponse, true);
    if($sdata==null){
      echo "<script type='text/javascript'> 
      alert ('No Rights to access this page ');
  window.open('index.php"."','_self');
  
  </script>";
  ;
    }
}
    ?>