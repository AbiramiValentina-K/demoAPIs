<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Icon Button Notification Badge</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" media="all" rel="stylesheet">
</head>

<body>
    <div class="message-show" id="message-show">
        <div class="message" id="message">
            <button type="button" class="icon-button">
                <span class="bell" id="bell-1">
                    <span class="anchor material-icons layer-1">notifications_active</span>
                    <span class="anchor material-icons layer-2">notifications</span>
                    <span class="anchor material-icons layer-3">notifications</span>
                </span>
                <span class="icon-button__badge" id="count"></span>
            </button>
        </div>
    </div>

</body>
<Script>
var stock = document.getElementById("material");

function getmaterial() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {


        if (this.readyState == 4 &&
            this.status == 200) {


            var myObj = JSON.parse(this.responseText);
            numRecord = myObj.length;
            if (numRecord == 0) {
                var element = document.getElementById("message-show");
                element.style.display = "none";
            }

            document.getElementById("count").innerHTML = numRecord;
            for (i = 0; i < myObj.length; i++) {
                materialDesc = myObj[i]['materialDescription'];
                document.getElementById("message").innerHTML += `
              <div class="container">
                <div class="row">
                <div class="col-md-12">
                  <div class="content-box">

                  <span class=notification>

                    <p class="content-box-sub" style="font-size: 12px; margin-bottom: 8px;">` + materialDesc + `</p>
                  </span>    
                  </div>
                  </div>
                  </div>
                  </div>
              `;

            }


        }
    };

    xmlhttp.open("GET", "getlowStockAlert.php", true);

    xmlhttp.send();
}
getmaterial();
</script>
<style>
    .icon-button {
        position: fixed;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        bottom: 20px;
        left: 95%;
        height: 50px;
        color: #333333;
        background: #dddddd;
        border: none;
        outline: none;
        border-radius: 50%;
    }

    .icon-button:hover {
        cursor: pointer;
    }

    .message-show {
        width: 150px;
        height: 430px;
        background: transparent;
        position: fixed;
        right: 0;
        margin-top: 120px;
        margin-right: -10px;
    }

    .message {
        position: absolute;
        bottom: 0;
    }

    .icon-button:active {
        background: #cccccc;
    }

    .icon-button__badge {
        position: fixed;
        right: 10px;
        bottom: 50px;
        width: 25px;
        height: 25px;
        background: red;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        animation: zoom 10s 3s both infinite;
    }

    .content-box {
        border-radius: 3px;
        box-shadow: 1px 1px 1px 1px black;
        animation: zoom 10s 3s both infinite;
        background-color: #cccccc;
        text-align: center;

    }

    @keyframes zoom {
        0% {
            opacity: 0;
            transform: scale(0);
        }

        10% {
            opacity: 1;
            transform: scale(1);
        }

        90% {
            opacity: 1;
        }

        100% {
            opacity: 0;
        }
    }


    .bell .material-icons {
        /* font-size:12rem !important; */
        font-size: 28px !important;
        /*font-size:16rem !important;*/
    }

    .bell {
        position: relative;
        display: inline-block;
        /* border:dashed 1px rgba(0,0,0,.25); */
        margin: 0;
        padding: 0;

    }

    .bell .anchor {
        transform-origin: center top;
        display: inline-block;
        margin: 0;
        padding: 0;
    }

    .bell .layer-1 {
        color: #1d1e22;
        z-index: 9;
        animation: animation-layer-1 5000ms infinite;
        opacity: 0;
    }

    .bell .layer-2 {
        color: #1d1e22;
        z-index: 8;
        position: absolute;
        top: 0;
        left: 0;
        animation: animation-layer-2 5000ms infinite;
    }

    .bell .layer-3 {
        color: #333642;
        z-index: 7;
        position: absolute;
        top: 0;
        left: 0;
        animation: animation-layer-3 5000ms infinite;
    }

    @keyframes animation-layer-1 {
        0% {
            transform: rotate(0deg);
            opacity: 0;
        }

        8.0% {
            transform: rotate(0deg);
            opacity: 0;
        }

        12.0% {
            transform: rotate(42deg);
            opacity: .5;
        }

        16.0% {
            transform: rotate(-35deg);
            opacity: .4;
        }

        20.0% {
            transform: rotate(0deg);
            opacity: .1;
        }

        23.0% {
            transform: rotate(28deg);
            opacity: .3;
        }

        26.0% {
            transform: rotate(-20deg);
            opacity: .2;
        }

        29.0% {
            transform: rotate(0deg);
            opacity: .1;
        }

        31.0% {
            transform: rotate(16deg);
            opacity: 0;
        }

        33.0% {
            transform: rotate(-12deg);
            opacity: 0;
        }

        35.0% {
            transform: rotate(0deg);
            opacity: 0;
        }

        37.0% {
            transform: rotate(-6deg);
            opacity: 0;
        }

        39.0% {
            transform: rotate(0deg);
            opacity: 0;
        }
    }

    @keyframes animation-layer-2 {
        0% {
            transform: rotate(0deg);
        }

        8.0% {
            transform: rotate(0deg);
        }

        12.0% {
            transform: rotate(42deg);
        }

        16.0% {
            transform: rotate(-35deg);
        }

        20.0% {
            transform: rotate(0deg);
        }

        23.0% {
            transform: rotate(28deg);
        }

        26.0% {
            transform: rotate(-20deg);
        }

        29.0% {
            transform: rotate(0deg);
        }

        31.0% {
            transform: rotate(16deg);
        }

        33.0% {
            transform: rotate(-12deg);
        }

        35.0% {
            transform: rotate(0deg);
        }

        37.0% {
            transform: rotate(-6deg);
        }

        39.0% {
            transform: rotate(0deg);
        }

        40.0% {
            transform: rotate(6deg);
        }

        44.0% {
            transform: rotate(-3deg);
        }

        49.0% {
            transform: rotate(2deg);
        }

        55.0% {
            transform: rotate(0deg);
        }

        62.0% {
            transform: rotate(1deg);
        }

        70.0% {
            transform: rotate(0deg);
        }
    }

    @keyframes animation-layer-3 {
        0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        8.0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        12.0% {
            transform: rotate(52deg);
            opacity: .5;
        }

        16.0% {
            transform: rotate(-48deg);
            opacity: .4;
        }

        20.0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        23.0% {
            transform: rotate(42deg);
            opacity: .3;
        }

        26.0% {
            transform: rotate(-30deg);
            opacity: .2;
        }

        29.0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        31.0% {
            transform: rotate(26deg);
            opacity: .15;
        }

        33.0% {
            transform: rotate(-18deg);
            opacity: .1;
        }

        35.0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        37.0% {
            transform: rotate(-12deg);
            opacity: .8;
        }

        40.0% {
            transform: rotate(6deg);
            opacity: 1;
        }

        44.0% {
            transform: rotate(-3deg);
            opacity: .8;
        }

        49.0% {
            transform: rotate(2deg);
            opacity: 1;
        }

        55.0% {
            transform: rotate(0deg);
            opacity: 1;
        }

        62.0% {
            transform: rotate(1deg);
            opacity: 1;
        };
    </style>
</html>